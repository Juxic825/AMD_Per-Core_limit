# Juxic Per-Core Limit — Windows x64

Juxic is a native Windows utility for viewing and adjusting AMD CPPC MaxPerf requests per physical core, applying values to all logical processors belonging to a selected core. It is intended to provide per-core performance-limit control on non-ASUS motherboards, including temperature management and adjustment of the maximum performance request.

## Features

- Rust frontend using Win32 APIs and GDI.
- C++20 Windows service for CPU access; GUI and service communicate through a local named pipe.
- CPPC range validation and readback, per-SMT values, batch rollback, and restoration of session changes.
- Separate active/effective clock readings.
- Presets, startup options, tray controls, bilingual UI, and light/dark themes.
- Single-file x64 distribution with the service embedded.

## Compatibility

The backend recognizes known Zen 4 and Zen 5 CPUID model groups and probes CPPC on each logical processor. Verified processors include Ryzen 9 7950X3D, Ryzen 9 9900X3D, and Ryzen 9 9950X3D. Other processor and firmware combinations require validation on the target hardware.

## Checking clock speeds

The Disable Processor Idle option helps you observe clock speeds after applying a limit. Use HWiNFO alongside Juxic to compare readings while tuning. Juxic samples clock speeds independently, keeping HWiNFO integration out of the background workload during gameplay.

## Requirements

- Windows 10/11 x64
- Administrator account
- PawnIO 2.2.0 installed from its official source

At first use, the application installs the embedded `Juxic.Service.exe` under Program Files and starts it as a Windows service.

## Build from source

Requirements: Rust stable `x86_64-pc-windows-msvc`, Visual Studio 2022 C++ Build Tools and Windows SDK, CMake 3.21+.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File native/build.ps1
```

Output: `bin/Release/juxic-single/Juxic Per-Core Limit.exe`.

Optional LLVM-MinGW build:

```powershell
native/build.ps1 -LlvmBin <llvm-mingw/bin>
```

This option requires Ninja.

## Current local build

File: `Juxic Per-Core Limit.exe`  
Size: 1,145,344 bytes  
SHA-256: `2E2487617681A0256173CC20714D278F2154A75851D5B0F3BBEE0D1746875B9C`

Recalculate the checksum after any rebuild before publishing.