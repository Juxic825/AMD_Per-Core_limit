# Zen 4 / Zen 5 compatibility

Juxic checks the AMD family/model for diagnostics and validates CPPC on every logical CPU before applying a request.

Known model groups:

- Zen 4: Family 19h models 18h, 61h, 74h, 75h and 78h.
- Zen 5: Family 1Ah models 08h, 24h, 44h, 60h and 70h.

A CPU is usable only when PawnIO is available, CPPC is enabled, the requested range is valid, and hardware readback succeeds. Other CPU, firmware and motherboard combinations require their own tests.

Verified models: Ryzen 9 7950X3D, Ryzen 9 9900X3D, and Ryzen 9 9950X3D. The 9950X3D test system has 16 physical cores / 32 logical CPUs.