#pragma once

#include <cstdint>

namespace amd {
struct Signature {
  unsigned family;
  unsigned model;
};

constexpr Signature signature(uint32_t eax) {
  const unsigned base_family = (eax >> 8) & 0xf;
  const unsigned base_model = (eax >> 4) & 0xf;
  const unsigned family = base_family + (base_family == 0xf ? ((eax >> 20) & 0xff) : 0);
  const unsigned model = base_model +
    ((base_family == 0xf || base_family == 6) ? ((eax >> 12) & 0xf0) : 0);
  return {family, model};
}

// Known CPUID models used by Ryzen and Threadripper. Several SKUs can share
// a signature. Initialization separately probes CPPC on each logical CPU.
constexpr bool client_cppc_candidate(Signature cpu) {
  if (cpu.family == 0x19) {
    switch (cpu.model) {
    case 0x18: // Storm Peak
    case 0x61: // Raphael and Dragon Range
    case 0x74: // Phoenix
    case 0x75: // Phoenix / Hawk Point
    case 0x78: // Phoenix 2
      return true;
    }
  }
  if (cpu.family == 0x1a) {
    switch (cpu.model) {
    case 0x08: // Shimada Peak
    case 0x24: // Strix Point
    case 0x44: // Granite Ridge and Fire Range
    case 0x60: // Krackan Point
    case 0x70: // Strix Halo
      return true;
    }
  }
  return false;
}

static_assert(signature(0x00a60f12).family == 0x19 && signature(0x00a60f12).model == 0x61);
static_assert(signature(0x00b40f40).family == 0x1a && signature(0x00b40f40).model == 0x44);
static_assert(client_cppc_candidate(signature(0x00a60f12))); // Raphael
static_assert(client_cppc_candidate(signature(0x00a70f80))); // Phoenix 2
static_assert(client_cppc_candidate(signature(0x00b40f40))); // Granite Ridge
static_assert(client_cppc_candidate({0x19, 0x18}) && client_cppc_candidate({0x1a, 0x08}));
static_assert(!client_cppc_candidate({0x19, 0x21}) && !client_cppc_candidate({0x17, 0x71}));
} // namespace amd
