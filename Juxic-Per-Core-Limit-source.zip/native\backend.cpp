#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

#include "amd_platform.h"

#include <algorithm>
#include <array>
#include <bcrypt.h>
#include <charconv>
#include <cstdint>
#include <cstdio>
#include <fcntl.h>
#include <iomanip>
#include <intrin.h>
#include <io.h>
#include <iostream>
#include <locale>
#include <map>
#include <memory>
#include <optional>
#include <powrprof.h>
#include <sddl.h>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>
#pragma comment(lib, "powrprof.lib")
#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "advapi32.lib")
using open_fn = int(__cdecl *)(void **);
using load_fn = int(__cdecl *)(void *, const unsigned char *, size_t);
using exec_fn = int(__cdecl *)(void *, const char *, const uint64_t *, size_t,
                               uint64_t *, size_t, size_t *);
static open_fn pawnio_open_p = nullptr;
static load_fn pawnio_load_p = nullptr;
static exec_fn pawnio_execute_p = nullptr;
struct Cpu {
  USHORT group;
  BYTE number;
};
struct Core {
  std::vector<Cpu> threads;
};
struct Limit {
  uint64_t request;
  BYTE highest;
};
struct Sample {
  uint64_t aperf;
  std::optional<int64_t> qpc;
  std::optional<uint64_t> mperf;
};
struct Clocks {
  std::optional<double> active;
  std::optional<double> effective;
};
static void verify_module(const void *data, DWORD size) {
  constexpr std::array<unsigned char, 32> expected = {
      0xDA, 0xE7, 0x46, 0x15, 0x76, 0x1B, 0x78, 0xBD, 0xF0, 0x64, 0xDF,
      0xB3, 0xE1, 0x36, 0x25, 0x2D, 0xDC, 0xC6, 0xFC, 0x72, 0x7D, 0x88,
      0xF1, 0x47, 0x38, 0xD0, 0xE5, 0x80, 0x0D, 0x42, 0x7A, 0x91};
  std::array<unsigned char, 32> actual{};
  BCRYPT_ALG_HANDLE algorithm{};
  if (BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr,
                                  0) < 0)
    throw std::runtime_error("SHA-256 unavailable");
  BCRYPT_HASH_HANDLE hash{};
  auto status = BCryptCreateHash(algorithm, &hash, nullptr, 0, nullptr, 0, 0);
  if (status >= 0)
    status = BCryptHashData(hash, (PUCHAR)data, size, 0);
  if (status >= 0)
    status = BCryptFinishHash(hash, actual.data(), actual.size(), 0);
  if (hash)
    BCryptDestroyHash(hash);
  BCryptCloseAlgorithmProvider(algorithm, 0);
  if (status < 0 || actual != expected)
    throw std::runtime_error("AMD module integrity check failed");
}
static unsigned number(const std::string &text) {
  unsigned value{};
  auto result = std::from_chars(text.data(), text.data() + text.size(), value);
  if (result.ec != std::errc{} || result.ptr != text.data() + text.size())
    throw std::runtime_error("invalid numeric input");
  return value;
}
static void check(int r, const char *op) {
  if (r < 0)
    throw std::runtime_error(op);
}
static void pcheck(ULONG r, const char *op) {
  if (r)
    throw std::runtime_error(op);
}
class Hardware {
  void *h_ = nullptr;
  HMODULE dll_ = nullptr;
  std::vector<Core> cores_;
  std::unordered_map<uint64_t, Sample> prior_;
  double nominal_mhz_ = 0;
  static constexpr uint64_t CAP = 0xC00102B0, ENABLE = 0xC00102B1,
                            REQUEST = 0xC00102B3, APERF = 0xC00000E8,
                            MPERF = 0xC00000E7;
  static uint64_t key(Cpu c) { return (uint64_t(c.group) << 8) | c.number; }
  static int64_t tick() {
    LARGE_INTEGER x{};
    if (!QueryPerformanceCounter(&x))
      throw std::runtime_error("query performance counter");
    return x.QuadPart;
  }
  static int64_t frequency() {
    static const int64_t f = [] {
      LARGE_INTEGER x{};
      return QueryPerformanceFrequency(&x) ? x.QuadPart : int64_t{0};
    }();
    return f;
  }
  static bool valid_mhz(double mhz) { return mhz >= 0 && mhz <= 10000; }
  template <class F> auto oncpu(Cpu c, F f) -> decltype(f()) {
    GROUP_AFFINITY a{}, o{};
    a.Mask = 1ull << c.number;
    a.Group = c.group;
    if (!SetThreadGroupAffinity(GetCurrentThread(), &a, &o))
      throw std::runtime_error("affinity");
    auto result = [&] {
      try {
        PROCESSOR_NUMBER current{};
        GetCurrentProcessorNumberEx(&current);
        if (current.Group != c.group || current.Number != c.number)
          throw std::runtime_error("could not select the requested CPU thread");
        return f();
      } catch (...) {
        SetThreadGroupAffinity(GetCurrentThread(), &o, nullptr);
        throw;
      }
    }();
    if (!SetThreadGroupAffinity(GetCurrentThread(), &o, nullptr))
      throw std::runtime_error("could not restore thread affinity");
    return result;
  }
  double nominal_reference(unsigned max_basic, unsigned max_extended) {
    int regs[4];
    if (max_basic >= 0x16) {
      __cpuidex(regs, 0x16, 0);
      double base = unsigned(regs[0]) & 0xffff;
      if (base >= 100 && valid_mhz(base))
        return base;
    }
    if (max_extended < 0x80000007u || frequency() <= 0)
      return 0;
    __cpuidex(regs, 0x80000007, 0);
    if (!(regs[3] & (1 << 8))) // Invariant TSC.
      return 0;
    try {
      return oncpu(cores_.front().threads.front(), [&] {
        auto stamp = [] {
          int64_t begin = tick();
          _mm_lfence();
          uint64_t cycles = __rdtsc();
          _mm_lfence();
          int64_t end = tick();
          return std::pair{cycles, begin + (end - begin) / 2};
        };
        std::array<double, 3> estimates{};
        for (auto &mhz : estimates) {
          auto [first, start] = stamp();
          Sleep(30);
          auto [last, end] = stamp();
          if (end <= start || last <= first)
            return 0.0;
          mhz = double(last - first) * double(frequency()) /
                double(end - start) / 1e6;
          if (mhz < 100 || !valid_mhz(mhz))
            return 0.0;
        }
        std::sort(estimates.begin(), estimates.end());
        return estimates.back() - estimates.front() <= estimates[1] * .01
                   ? estimates[1]
                   : 0.0;
      });
    } catch (const std::exception &) {
      return 0;
    }
  }
  uint64_t msr(uint64_t n) {
    uint64_t i[1] = {n}, o[1] = {};
    size_t c = 0;
    check(pawnio_execute_p(h_, "ioctl_read_msr", i, 1, o, 1, &c), "read MSR");
    if (c != 1)
      throw std::runtime_error("bad PawnIO length");
    return o[0];
  }
  void sample(Cpu c, Clocks &core) {
    try {
      auto now = oncpu(c, [&] {
        auto timestamp = []() -> std::optional<int64_t> {
          try {
            return tick();
          } catch (const std::exception &) {
            return std::nullopt;
          }
        };
        auto start = timestamp();
        auto aperf = msr(APERF);
        auto end = timestamp();
        Sample current{aperf, std::nullopt, std::nullopt};
        if (start && end && *end >= *start)
          current.qpc = *start + (*end - *start) / 2;
        if (nominal_mhz_ > 0) {
          try {
            current.mperf = msr(MPERF);
          } catch (const std::exception &) {
            // An unavailable MPERF must not suppress the effective clock.
          }
        }
        return current;
      });
      auto [it, inserted] = prior_.try_emplace(key(c), now);
      if (inserted)
        return;
      Sample prev = it->second;
      it->second = now;
      if (now.aperf < prev.aperf)
        return;
      auto delta = double(now.aperf - prev.aperf);
      auto update_max = [](std::optional<double> &value, double mhz) {
        if (valid_mhz(mhz) && (!value || mhz > *value))
          value = mhz;
      };
      if (now.mperf && prev.mperf && *now.mperf > *prev.mperf)
        update_max(core.active,
                   nominal_mhz_ * delta / double(*now.mperf - *prev.mperf));
      if (now.qpc && prev.qpc && *now.qpc > *prev.qpc && frequency() > 0)
        update_max(core.effective, delta * double(frequency()) /
                                       double(*now.qpc - *prev.qpc) / 1e6);
    } catch (const std::exception &) {
      prior_.erase(key(c));
    }
  }
  Limit lim(Cpu c) {
    return oncpu(c, [&] {
      if (!(msr(ENABLE) & 1))
        throw std::runtime_error("CPPC disabled");
      uint64_t r = msr(REQUEST);
      return Limit{r, (BYTE)(msr(CAP) >> 24)};
    });
  }

public:
  Hardware() {
    try {
      initialize();
    } catch (...) {
      release();
      throw;
    }
  }
  ~Hardware() { release(); }

private:
  void initialize() {
    dll_ = LoadLibraryW(L"C:\\Program Files\\PawnIO\\PawnIOLib.dll");
    if (!dll_)
      throw std::runtime_error("PawnIO library unavailable");
    pawnio_open_p = (open_fn)GetProcAddress(dll_, "pawnio_open");
    pawnio_load_p = (load_fn)GetProcAddress(dll_, "pawnio_load");
    pawnio_execute_p = (exec_fn)GetProcAddress(dll_, "pawnio_execute");
    if (!pawnio_open_p || !pawnio_load_p || !pawnio_execute_p)
      throw std::runtime_error("PawnIO API unavailable");
    int x[4];
    __cpuidex(x, 0, 0);
    const auto max_basic = unsigned(x[0]);
    if (max_basic < 1 || x[1] != 0x68747541 || x[3] != 0x69746e65 ||
        x[2] != 0x444d4163)
      throw std::runtime_error("unsupported CPU vendor");
    __cpuidex(x, 1, 0);
    const auto cpu = amd::signature(static_cast<uint32_t>(x[0]));
    if (!amd::client_cppc_candidate(cpu)) {
      std::ostringstream message;
      message << "Unsupported AMD CPU (family " << std::hex << cpu.family
              << "h, model " << cpu.model << "h)";
      throw std::runtime_error(message.str());
    }
    __cpuidex(x, 0x80000000, 0);
    const auto max_extended = unsigned(x[0]);
    if (max_extended < 0x80000008u)
      throw std::runtime_error("CPPC unavailable");
    __cpuidex(x, 0x80000008, 0);
    if (!(x[1] & (1 << 27)))
      throw std::runtime_error("CPPC unavailable");
    HRSRC r = FindResourceA(nullptr, (LPCSTR)MAKEINTRESOURCEA(101),
                            (LPCSTR)MAKEINTRESOURCEA(10));
    if (!r)
      throw std::runtime_error("AMD resource missing");
    HGLOBAL g = LoadResource(nullptr, r);
    void *p = LockResource(g);
    DWORD n = SizeofResource(nullptr, r);
    if (!p || !n)
      throw std::runtime_error("AMD resource invalid");
    verify_module(p, n);
    check(pawnio_open_p(&h_), "open PawnIO");
    try {
      check(pawnio_load_p(h_, (const unsigned char *)p, n), "load AMD module");
    } catch (...) {
      CloseHandle(h_);
      h_ = nullptr;
      throw;
    }
    DWORD z = 0;
    GetLogicalProcessorInformationEx(RelationProcessorCore, nullptr, &z);
    std::vector<unsigned char> b(z);
    if (!GetLogicalProcessorInformationEx(
            RelationProcessorCore,
            (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)b.data(), &z))
      throw std::runtime_error("topology");
    for (DWORD o = 0; o < z;) {
      auto *x = (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)(b.data() + o);
      Core c;
      for (WORD i = 0; i < x->Processor.GroupCount; i++)
        for (BYTE j = 0; j < 64; j++)
          if (x->Processor.GroupMask[i].Mask & (1ull << j))
            c.threads.push_back({x->Processor.GroupMask[i].Group, j});
      if (c.threads.empty())
        throw std::runtime_error("physical core has no logical CPUs");
      cores_.push_back(std::move(c));
      o += x->Size;
    }
    if (cores_.empty())
      throw std::runtime_error("empty CPU topology");
    std::sort(cores_.begin(), cores_.end(), [](const Core &a, const Core &b) {
      return key(a.threads.front()) < key(b.threads.front());
    });
    for (const auto &core : cores_) {
      for (const auto thread : core.threads) {
        try {
          const auto limit = lim(thread);
          if (!limit.highest || !(limit.request & 0xff) ||
              ((limit.request >> 8) & 0xff) > limit.highest)
            throw std::runtime_error("invalid CPPC performance range");
        } catch (const std::exception &error) {
          throw std::runtime_error("CPPC unavailable on CPU group " +
                                   std::to_string(thread.group) + ", thread " +
                                   std::to_string(thread.number) + ": " + error.what());
        }
      }
    }
    nominal_mhz_ = nominal_reference(max_basic, max_extended);
  }
  void release() noexcept {
    if (h_)
      CloseHandle(h_);
    if (dll_)
      FreeLibrary(dll_);
  }

public:
  const std::vector<Core> &cores() const { return cores_; }
  std::vector<Limit> snap(size_t i, Clocks *clocks = nullptr) {
    std::vector<Limit> limits;
    for (auto c : cores_[i].threads) {
      limits.push_back(lim(c));
      if (clocks)
        sample(c, *clocks);
    }
    return limits;
  }
  template <class BeforeWrite>
  void write(Cpu c, BYTE target, bool restoring, BeforeWrite before_write) {
    oncpu(c, [&] {
      if (!(msr(ENABLE) & 1))
        throw std::runtime_error("CPPC disabled");
      uint64_t request = msr(REQUEST);
      BYTE current = (BYTE)request;
      if (current == target)
        return 0;
      if (!restoring && (!target || !current || target < (BYTE)(request >> 8) ||
                        target > (BYTE)(msr(CAP) >> 24)))
        throw std::runtime_error("invalid current CPPC range");
      uint64_t input[2] = {REQUEST, (request & ~255ull) | target};
      size_t count = 0;
      before_write(current);
      int result = pawnio_execute_p(h_, "ioctl_write_msr", input, 2, nullptr,
                                     0, &count);
      if (!restoring)
        check(result, "write CPPC");
      // On restore, verify the actual byte even if the driver reported failure.
      if ((BYTE)msr(REQUEST) != target) {
        check(result, "write CPPC");
        throw std::runtime_error("CPPC readback mismatch");
      }
      return 0;
    });
  }
  void restore(Cpu c, BYTE target) {
    write(c, target, true, [](BYTE) {});
  }
};
struct IdleState {
  GUID plan{};
  DWORD ac = 0, dc = 0;
  bool disabled() const { return ac == 1 && dc == 1; }
};
static const GUID kProcessor = {
    0x54533251,
    0x82be,
    0x4824,
    {0x96, 0xc1, 0x47, 0xb6, 0x0b, 0x74, 0x0d, 0x00}};
static const GUID kIdle = {0x5d76a2ca,
                           0xe8c0,
                           0x402f,
                           {0xa1, 0x33, 0x21, 0x58, 0x49, 0x2d, 0x58, 0xad}};
static GUID active_plan() {
  GUID *p = nullptr;
  pcheck(PowerGetActiveScheme(nullptr, &p), "read active power plan");
  if (!p)
    throw std::runtime_error("active power plan unavailable");
  GUID plan = *p;
  LocalFree(p);
  return plan;
}
static DWORD idle_value(const GUID &plan, bool ac) {
  DWORD value = 0;
  ULONG result = ac ? PowerReadACValueIndex(nullptr, &plan, &kProcessor,
                                            &kIdle, &value)
                    : PowerReadDCValueIndex(nullptr, &plan, &kProcessor,
                                            &kIdle, &value);
  pcheck(result, ac ? "read AC idle setting" : "read DC idle setting");
  return value;
}
static IdleState idle_read() {
  GUID plan = active_plan();
  return {plan, idle_value(plan, true), idle_value(plan, false)};
}
static ULONG idle_write(const GUID &plan, bool ac, DWORD value) {
  return ac ? PowerWriteACValueIndex(nullptr, &plan, &kProcessor, &kIdle, value)
            : PowerWriteDCValueIndex(nullptr, &plan, &kProcessor, &kIdle, value);
}
static void idle_restore(const GUID &plan, bool ac, DWORD value) {
  if (idle_value(plan, ac) == value) return;
  ULONG result = idle_write(plan, ac, value);
  if (idle_value(plan, ac) != value) {
    pcheck(result, ac ? "restore AC idle setting" : "restore DC idle setting");
    throw std::runtime_error(ac ? "AC idle setting restore mismatch" : "DC idle setting restore mismatch");
  }
}
static void idle_apply_if_active(const GUID &plan, bool required) {
  if (IsEqualGUID(active_plan(), plan)) pcheck(PowerSetActiveScheme(nullptr, &plan), "apply idle settings");
  else if (required) throw std::runtime_error("active power plan changed; retry");
}
static void append_error(std::string &errors, const std::string &location, const std::exception &error) {
  if (!errors.empty()) errors += "; ";
  errors += location + ": " + error.what();
}
class Session {
  HANDLE lock_ = nullptr;
  struct IdleBaseline { GUID plan; std::array<std::optional<DWORD>, 2> values{}; bool needs_apply = false; };
  std::vector<IdleBaseline> idle_;
  std::map<std::pair<USHORT, BYTE>, BYTE> cpu_;
public:
  ~Session() { if (lock_) { ReleaseMutex(lock_); CloseHandle(lock_); } }
  void lock() {
    if (lock_) return;
    PSECURITY_DESCRIPTOR descriptor = nullptr;
    if (!ConvertStringSecurityDescriptorToSecurityDescriptorW(L"D:P(A;;GA;;;SY)(A;;GA;;;BA)", SDDL_REVISION_1, &descriptor, nullptr)) throw std::runtime_error("could not configure hardware session lock");
    SECURITY_ATTRIBUTES attrs{sizeof(SECURITY_ATTRIBUTES), descriptor, FALSE};
    HANDLE mutex = CreateMutexW(&attrs, FALSE, L"Global\\JuxicHardwareSession");
    LocalFree(descriptor);
    if (!mutex) throw std::runtime_error("could not open hardware session lock; close other Juxic instances");
    DWORD result = WaitForSingleObject(mutex, 0);
    if (result != WAIT_OBJECT_0 && result != WAIT_ABANDONED) {
      CloseHandle(mutex);
      if (result == WAIT_TIMEOUT) throw std::runtime_error("hardware is in use; close the other Juxic session and retry");
      throw std::runtime_error("could not acquire hardware session lock");
    }
    lock_ = mutex;
  }
  struct CpuWrite { Cpu cpu; BYTE target; std::optional<BYTE> before; bool new_baseline = false; };
  void write(Hardware &hw, CpuWrite &change) {
    hw.write(change.cpu, change.target, false, [&](BYTE current) {
      auto key = std::pair{change.cpu.group, change.cpu.number};
      change.new_baseline = cpu_.try_emplace(key, current).second;
      change.before = current;
    });
  }
  void rollback(Hardware &hw, const CpuWrite &change) {
    if (!change.before) return;
    hw.restore(change.cpu, *change.before);
    if (change.new_baseline) cpu_.erase(std::pair{change.cpu.group, change.cpu.number});
  }
  IdleState idle_toggle() {
    IdleState old = idle_read(); DWORD target = old.disabled() ? 0 : 1;
    auto it = std::find_if(idle_.begin(), idle_.end(), [&](const auto &x) { return IsEqualGUID(x.plan, old.plan); });
    if (it == idle_.end()) { idle_.push_back({old.plan}); it = idle_.end() - 1; }
    auto &saved = *it; auto previous = saved; std::array<std::optional<DWORD>, 2> before{};
    try {
      for (size_t i = 0; i < 2; ++i) {
        bool ac = i == 0; DWORD current = idle_value(old.plan, ac);
        if (current == target) continue;
        if (!saved.values[i]) saved.values[i] = current;
        before[i] = current; saved.needs_apply = true;
        pcheck(idle_write(old.plan, ac, target), ac ? "write AC idle setting" : "write DC idle setting");
      }
      idle_apply_if_active(old.plan, true);
      IdleState after = idle_read();
      if (!IsEqualGUID(after.plan, old.plan) || after.ac != target || after.dc != target) throw std::runtime_error("idle setting readback mismatch");
      saved.needs_apply = false; return after;
    } catch (const std::exception &original) {
      std::string errors;
      for (size_t i = 0; i < 2; ++i) if (before[i]) {
        try { idle_restore(old.plan, i == 0, *before[i]); saved.values[i] = previous.values[i]; }
        catch (const std::exception &e) { append_error(errors, i == 0 ? "AC rollback" : "DC rollback", e); }
      }
      if (saved.needs_apply) try { idle_apply_if_active(old.plan, false); saved.needs_apply = false; }
      catch (const std::exception &e) { append_error(errors, "idle rollback apply", e); }
      if (!errors.empty()) throw std::runtime_error(std::string(original.what()) + "; " + errors);
      throw;
    }
  }
  std::string restore(Hardware *hw) {
    std::string errors;
    for (auto &saved : idle_) {
      for (size_t i = 0; i < 2; ++i) if (saved.values[i]) {
        saved.needs_apply = true;
        try { idle_restore(saved.plan, i == 0, *saved.values[i]); saved.values[i].reset(); }
        catch (const std::exception &e) { append_error(errors, i == 0 ? "AC idle restore" : "DC idle restore", e); }
      }
      if (saved.needs_apply) try { idle_apply_if_active(saved.plan, false); saved.needs_apply = false; }
      catch (const std::exception &e) { append_error(errors, "idle restore apply", e); }
    }
    bool idle_pending = !errors.empty();
    for (auto it = cpu_.begin(); it != cpu_.end();) {
      auto [group, number] = it->first;
      try { hw->restore({group, number}, it->second); if (!idle_pending) { it = cpu_.erase(it); continue; } }
      catch (const std::exception &e) { append_error(errors, "CPU " + std::to_string(group) + ":" + std::to_string(number) + " restore", e); }
      ++it;
    }
    return errors;
  }
};
static std::string trim(std::string s) {
  size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
  return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}
static std::string snapshot_reply(Hardware &hw) {
  std::ostringstream reply;
  reply.imbue(std::locale::classic());
  reply << "OK\n" << std::fixed;
  for (size_t i = 0; i < hw.cores().size(); i++) {
    Clocks clocks;
    auto ls = hw.snap(i, &clocks);
    int mn = 1, hi = 255;
    for (auto l : ls) { mn = std::max(mn, (int)(BYTE)(l.request >> 8)); hi = std::min(hi, (int)l.highest); }
    reply << "CORE " << i << ' ' << mn << ' ' << hi << ' ';
    if (clocks.active) reply << std::setprecision(1) << *clocks.active; else reply << '-';
    reply << ' ';
    if (clocks.effective) reply << std::setprecision(0) << *clocks.effective; else reply << '-';
    reply << ' ';
    for (size_t j = 0; j < ls.size(); j++) { if (j) reply << ','; reply << (unsigned)(BYTE)ls[j].request; }
    reply << '\n';
  }
  try { auto idle = idle_read(); reply << "IDLE " << (idle.disabled() ? 1 : 0) << '\n'; }
  catch (...) { reply << "IDLE -\n"; }
  reply << "END\n";
  return reply.str();
}
class PipeTransport {
  HANDLE input_, output_;
  std::string buffered_;
public:
  PipeTransport(HANDLE input, HANDLE output) : input_(input), output_(output) {}
  bool read_line(std::string &line) {
    for (;;) {
      auto end = buffered_.find('\n');
      if (end != std::string::npos) {
        line = buffered_.substr(0, end);
        buffered_.erase(0, end + 1);
        return true;
      }
      char chunk[1024];
      DWORD count = 0;
      if (buffered_.size() >= 8192 || !ReadFile(input_, chunk, sizeof(chunk), &count, nullptr) || count == 0) return false;
      buffered_.append(chunk, count);
    }
  }
  bool send(const std::string &reply) {
    DWORD written = 0;
    return WriteFile(output_, reply.data(), static_cast<DWORD>(reply.size()), &written, nullptr) && written == reply.size();
  }
};
static int run_backend(HANDLE input, HANDLE output) {
  PipeTransport pipe(input, output);
  std::unique_ptr<Hardware> hw;
  Session session;
  std::string line;
  while (pipe.read_line(line)) {
    line = trim(line);
    if (line.empty())
      continue;
    try {
      if (line == "restore" || line == "quit") {
        std::string errors = session.restore(hw.get());
        if (!errors.empty()) throw std::runtime_error("restore failed: " + errors);
        if (!pipe.send("OK\nEND\n") || line == "quit") break;
        continue;
      }
      if (line == "idle-toggle") {
        session.lock();
        auto state = session.idle_toggle();
        if (!pipe.send(state.disabled() ? "OK\nIDLE 1\nEND\n" : "OK\nIDLE 0\nEND\n")) break;
        continue;
      }
      if (line == "read") {
        session.lock();
        if (!hw) hw = std::make_unique<Hardware>();
        if (!pipe.send(snapshot_reply(*hw))) break; continue;
      }
      if (line.rfind("apply ", 0) != 0)
        throw std::runtime_error("unknown command");
      session.lock();
      if (!hw) hw = std::make_unique<Hardware>();
      std::istringstream in(line.substr(6));
      std::map<size_t, std::vector<std::string>> values;
      std::string token;
      while (in >> token) {
        size_t eq = token.find('=');
        if (eq == std::string::npos)
          throw std::runtime_error("invalid apply syntax");
        std::string cs = token.substr(0, eq), vs = token.substr(eq + 1);
        size_t idx = number(cs);
        if (vs.empty() || vs.back() == ',')
          throw std::runtime_error("missing Perf value");
        if (idx >= hw->cores().size())
          throw std::runtime_error("core index out of range");
        std::vector<std::string> vv;
        std::stringstream ss(vs);
        while (std::getline(ss, token, ','))
          vv.push_back(token);
        if (vv.size() != 1 && vv.size() != hw->cores()[idx].threads.size())
          throw std::runtime_error("wrong SMT value count");
        if (!values.emplace(idx, vv).second)
          throw std::runtime_error("duplicate core");
      }
      if (values.empty())
        throw std::runtime_error("no cores specified");
      std::vector<Session::CpuWrite> targets;
      for (auto &[idx, vv] : values) {
        auto ls = hw->snap(idx, nullptr);
        for (size_t j = 0; j < ls.size(); j++) {
          const auto &input = vv[vv.size() == 1 ? 0 : j];
          int val = input == "A" || input == "a" ? ls[j].highest : number(input);
          int min = std::max(1, (int)(BYTE)(ls[j].request >> 8));
          if (!(BYTE)ls[j].request || val < min || val > ls[j].highest || val > 255) throw std::runtime_error("MaxPerf outside allowed range");
          targets.push_back({hw->cores()[idx].threads[j], (BYTE)val});
        }
      }
      size_t done = 0;
      try {
        while (done < targets.size()) { auto &target = targets[done++]; session.write(*hw, target); }
        for (auto &[idx, vv] : values) {
          auto after = hw->snap(idx);
          for (size_t j = 0; j < after.size(); j++) {
            unsigned value = (BYTE)after[j].request;
            const auto &input = vv[vv.size() == 1 ? 0 : j];
            if (value != (input == "A" || input == "a" ? after[j].highest : number(input))) throw std::runtime_error("batch readback mismatch");
          }
        }
      } catch (...) {
        bool rollback_failed = false;
        while (done) { --done; try { session.rollback(*hw, targets[done]); } catch (...) { rollback_failed = true; } }
        if (rollback_failed) throw std::runtime_error("CPPC transaction and rollback failed");
        throw;
      }
      if (!pipe.send(snapshot_reply(*hw))) break;
    } catch (const std::exception &e) {
      if (!pipe.send(std::string("ERR ") + e.what() + "\nEND\n")) break;
    }
  }
  std::string ignored = session.restore(hw.get());
  if (!ignored.empty()) {
    OutputDebugStringA(("Juxic: restore after disconnect failed: " + ignored).c_str());
    return 1;
  }
  return 0;
}

extern "C" int juxic_backend_stdio(void *input, void *output) {
  int result = run_backend(input, output);
  CloseHandle(input);
  CloseHandle(output);
  return result;
}
extern "C" int juxic_backend_main() {
  return run_backend(GetStdHandle(STD_INPUT_HANDLE), GetStdHandle(STD_OUTPUT_HANDLE));
}