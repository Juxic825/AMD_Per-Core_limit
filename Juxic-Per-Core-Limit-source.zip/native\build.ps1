param(
    [string]$LlvmBin,
    [string]$Cargo,
    [string]$Toolchain,
    [string]$CMake,
    [string]$Ninja
)

$ErrorActionPreference = 'Stop'
$localTools = Join-Path $PSScriptRoot '../.native-tools'
$target = 'x86_64-pc-windows-msvc'
if ($LlvmBin) {
    $target = 'x86_64-pc-windows-gnullvm'
    $env:JUXIC_LLVM_BIN = (Resolve-Path -LiteralPath $LlvmBin).Path
    $env:CARGO_TARGET_X86_64_PC_WINDOWS_GNULLVM_LINKER = Join-Path $env:JUXIC_LLVM_BIN 'x86_64-w64-mingw32-clang.exe'
}
if (!$Toolchain) { $Toolchain = "stable-$target" }

if (!$Cargo) {
    $localCargo = Join-Path $localTools 'cargo/bin/cargo.exe'
    if (Test-Path -LiteralPath $localCargo -PathType Leaf) {
        $Cargo = (Resolve-Path -LiteralPath $localCargo).Path
        if (!$env:CARGO_HOME) { $env:CARGO_HOME = (Resolve-Path -LiteralPath (Join-Path $localTools 'cargo')).Path }
        if (!$env:RUSTUP_HOME) { $env:RUSTUP_HOME = (Resolve-Path -LiteralPath (Join-Path $localTools 'rustup')).Path }
    } else {
        $Cargo = 'cargo'
    }
}
if (Test-Path -LiteralPath $Cargo -PathType Leaf) { $Cargo = (Resolve-Path -LiteralPath $Cargo).Path }

$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
if (Test-Path -LiteralPath $vswhere -PathType Leaf) {
    $vs = & $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
}
if (!$LlvmBin -and !$vs) {
    throw 'Visual Studio C++ Build Tools and the Windows SDK are required. For LLVM, supply -LlvmBin pointing to llvm-mingw/bin.'
}

if ($CMake) { $env:JUXIC_CMAKE = (Resolve-Path -LiteralPath $CMake).Path }
if ($Ninja) { $env:JUXIC_NINJA = (Resolve-Path -LiteralPath $Ninja).Path }
if ($vs) {
    $vsCMakeTools = Join-Path $vs 'Common7/IDE/CommonExtensions/Microsoft/CMake'
    $vsCMake = Join-Path $vsCMakeTools 'CMake/bin/cmake.exe'
    $vsNinja = Join-Path $vsCMakeTools 'Ninja/ninja.exe'
    if (!$env:JUXIC_CMAKE -and !(Get-Command cmake.exe -ErrorAction SilentlyContinue) -and (Test-Path -LiteralPath $vsCMake)) {
        $env:JUXIC_CMAKE = $vsCMake
    }
    if ($LlvmBin -and !$env:JUXIC_NINJA -and !(Get-Command ninja.exe -ErrorAction SilentlyContinue) -and (Test-Path -LiteralPath $vsNinja)) {
        $env:JUXIC_NINJA = $vsNinja
    }
}
if (!$env:JUXIC_CMAKE -and !(Get-Command cmake.exe -ErrorAction SilentlyContinue)) {
    throw 'CMake 3.21 or later is required. Add it to PATH or pass -CMake.'
}
if ($LlvmBin -and !$env:JUXIC_NINJA -and !(Get-Command ninja.exe -ErrorAction SilentlyContinue)) {
    throw 'Ninja is required for llvm-mingw. Add it to PATH or pass -Ninja.'
}

$publish = Join-Path $PSScriptRoot '../bin/Release/juxic-single'
$targetDir = Join-Path $PSScriptRoot 'target'
Push-Location $PSScriptRoot
try {
    & $Cargo "+$Toolchain" build --locked --release --target $target --target-dir $targetDir
    if ($LASTEXITCODE -ne 0) { throw "Cargo compilation for $target failed with exit code $LASTEXITCODE." }
    New-Item -ItemType Directory -Force -Path $publish | Out-Null
    $releaseExe = Join-Path $targetDir "$target/release/juxic.exe"
    $publishedExe = Join-Path $publish 'Juxic Per-Core Limit.exe'
    Copy-Item -LiteralPath $releaseExe -Destination $publishedExe -Force
    Write-Output (Resolve-Path -LiteralPath $publishedExe).Path
} finally {
    Pop-Location
}
