use std::{env, fs, path::PathBuf, process::Command};

fn run(command: &mut Command) {
    let status = command
        .status()
        .unwrap_or_else(|error| panic!("could not start {command:?}: {error}"));
    assert!(status.success(), "{command:?} failed: {status}");
}

fn main() {
    for source in [
        "CMakeLists.txt",
        "service.cpp",
        "backend.cpp",
        "amd_platform.h",
        "backend.rc",
        "frontend.rc",
        "frontend.manifest",
        "Juxic.ico",
        "../cppc-deps/modules/AMDFamily17.bin",
    ] {
        println!("cargo:rerun-if-changed={source}");
    }
    for key in [
        "JUXIC_CMAKE",
        "JUXIC_NINJA",
        "JUXIC_MSVC_GENERATOR",
        "JUXIC_LLVM_BIN",
    ] {
        println!("cargo:rerun-if-env-changed={key}");
    }

    let target = env::var("TARGET").unwrap();
    let msvc = match target.as_str() {
        "x86_64-pc-windows-msvc" => true,
        "x86_64-pc-windows-gnullvm" => false,
        _ => panic!("unsupported Juxic target {target}; use x86_64-pc-windows-msvc or x86_64-pc-windows-gnullvm"),
    };
    let source = PathBuf::from(env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let out = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    let build = out.join("cmake");
    let config = if env::var("PROFILE").as_deref() == Ok("release") {
        "Release"
    } else {
        "Debug"
    };
    let cmake = env::var_os("JUXIC_CMAKE").unwrap_or_else(|| "cmake".into());
    let mut configure = Command::new(&cmake);
    configure.arg("-S").arg(source).arg("-B").arg(&build);
    if msvc {
        let generator =
            env::var_os("JUXIC_MSVC_GENERATOR").unwrap_or_else(|| "Visual Studio 17 2022".into());
        configure.arg("-G").arg(generator).args(["-A", "x64"]);
    } else {
        let llvm = env::var_os("JUXIC_LLVM_BIN").map(PathBuf::from);
        configure.args(["-G", "Ninja", &format!("-DCMAKE_BUILD_TYPE={config}")]);
        for (variable, executable) in [
            ("CMAKE_CXX_COMPILER", "x86_64-w64-mingw32-clang++.exe"),
            ("CMAKE_RC_COMPILER", "x86_64-w64-mingw32-windres.exe"),
        ] {
            let tool = llvm
                .as_ref()
                .map_or_else(|| PathBuf::from(executable), |bin| bin.join(executable));
            configure.arg(format!(
                "-D{variable}:FILEPATH={}",
                tool.to_string_lossy().replace('\\', "/")
            ));
        }
        if let Ok(ninja) = env::var("JUXIC_NINJA") {
            configure.arg(format!("-DCMAKE_MAKE_PROGRAM:FILEPATH={}", ninja.replace('\\', "/")));
        }
    }
    run(&mut configure);
    run(Command::new(cmake)
        .arg("--build")
        .arg(&build)
        .args(["--config", config, "--target", "JuxicService", "JuxicFrontend"]));

    let artifacts = build.join("bin").join(config);
    let service = "Juxic.Service.exe";
    fs::copy(artifacts.join(service), out.join(service)).expect("stage service for GUI embedding");
    let resource = artifacts.join(if msvc { "frontend.res" } else { "frontend.o" });
    if msvc {
        // The resource already supplies manifest #1, including UAC and Common Controls v6.
        println!("cargo:rustc-link-arg-bin=juxic=/MANIFEST:NO");
    }
    println!("cargo:rustc-link-arg-bin=juxic={}", resource.display());
}
