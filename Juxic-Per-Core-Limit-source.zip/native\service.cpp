#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <sddl.h>

#include <cstring>

extern "C" int juxic_backend_stdio(void *input, void *output);

namespace {
constexpr wchar_t service_name[] = L"Juxic.Service";
constexpr wchar_t pipe_name[] = L"\\\\.\\pipe\\Juxic.Service.v1";
constexpr char hello[] = "JUXIC/1\n";
constexpr char accepted[] = "JUXIC/1 OK\n";
constexpr DWORD rollback_failed = 1;
constexpr DWORD transport_failed = 2;
SERVICE_STATUS_HANDLE status_handle;
HANDLE stop_requested;

class Handle {
  HANDLE value_;
public:
  explicit Handle(HANDLE value) : value_(value) {}
  ~Handle() { if (value_ && value_ != INVALID_HANDLE_VALUE) CloseHandle(value_); }
  Handle(const Handle &) = delete;
  Handle &operator=(const Handle &) = delete;
  HANDLE get() const { return value_; }
};

void report_status(DWORD state, DWORD error = NO_ERROR, DWORD checkpoint = 0) {
  SERVICE_STATUS status{};
  status.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
  status.dwCurrentState = state;
  status.dwControlsAccepted = state == SERVICE_RUNNING ? SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN : 0;
  if (error) {
    status.dwWin32ExitCode = ERROR_SERVICE_SPECIFIC_ERROR;
    status.dwServiceSpecificExitCode = error;
  }
  status.dwCheckPoint = checkpoint;
  status.dwWaitHint = checkpoint ? 10000 : 0;
  SetServiceStatus(status_handle, &status);
}

DWORD WINAPI control(DWORD code, DWORD, void *, void *) {
  if (code == SERVICE_CONTROL_STOP || code == SERVICE_CONTROL_SHUTDOWN) {
    SetEvent(stop_requested);
    return NO_ERROR;
  }
  return code == SERVICE_CONTROL_INTERROGATE ? NO_ERROR : ERROR_CALL_NOT_IMPLEMENTED;
}

bool local_system() {
  HANDLE raw_token;
  if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &raw_token)) return false;
  Handle token(raw_token);
  // TOKEN_USER followed by its SID, both naturally aligned.
  alignas(TOKEN_USER) unsigned char storage[sizeof(TOKEN_USER) + SECURITY_MAX_SID_SIZE];
  DWORD size;
  return GetTokenInformation(token.get(), TokenUser, storage, sizeof(storage), &size) &&
         IsWellKnownSid(reinterpret_cast<TOKEN_USER *>(storage)->User.Sid, WinLocalSystemSid);
}

bool read_hello(HANDLE pipe) {
  char message[sizeof(hello) - 1];
  DWORD length = 0;
  while (length < sizeof(message)) {
    DWORD count;
    if (!ReadFile(pipe, message + length, sizeof(message) - length, &count, nullptr) || !count) return false;
    length += count;
  }
  return !std::memcmp(message, hello, sizeof(message));
}

// Check the effective client token attached to the pipe's last read. The ACL
// also enforces enabled membership before the client can open the endpoint.
bool authorize(HANDLE pipe) {
  if (!ImpersonateNamedPipeClient(pipe)) return false;
  DWORD size = SECURITY_MAX_SID_SIZE;
  alignas(DWORD) unsigned char admin[SECURITY_MAX_SID_SIZE];
  BOOL member = FALSE;
  bool allowed = CreateWellKnownSid(WinBuiltinAdministratorsSid, nullptr, admin, &size) &&
                 CheckTokenMembership(nullptr, admin, &member) && member;
  if (!RevertToSelf()) TerminateProcess(GetCurrentProcess(), ERROR_CANNOT_IMPERSONATE);
  return allowed;
}

DWORD WINAPI serve(void *ready_event) {
  PSECURITY_DESCRIPTOR descriptor;
  // Administrators can read/write existing data only. FILE_WRITE_DATA is
  // granted explicitly because GENERIC_WRITE also grants pipe instance creation.
  if (!ConvertStringSecurityDescriptorToSecurityDescriptorW(
          L"O:SYG:SYD:P(A;;GA;;;SY)(A;;GA;;;BA)", SDDL_REVISION_1, &descriptor, nullptr))
    return transport_failed;
  SECURITY_ATTRIBUTES security{sizeof(security), descriptor, FALSE};
  Handle pipe(CreateNamedPipeW(pipe_name, PIPE_ACCESS_DUPLEX | FILE_FLAG_FIRST_PIPE_INSTANCE,
                               PIPE_REJECT_REMOTE_CLIENTS,
                               1, 65536, 65536, 0, &security));
  LocalFree(descriptor);
  if (pipe.get() == INVALID_HANDLE_VALUE || !SetEvent(ready_event)) return transport_failed;

  while (WaitForSingleObject(stop_requested, 0) == WAIT_TIMEOUT) {
    if (!ConnectNamedPipe(pipe.get(), nullptr)) {
      DWORD error = GetLastError();
      if (error == ERROR_OPERATION_ABORTED && WaitForSingleObject(stop_requested, 0) == WAIT_OBJECT_0) return NO_ERROR;
      if (error == ERROR_NO_DATA) {
        DisconnectNamedPipe(pipe.get());
        continue;
      }
      if (error != ERROR_PIPE_CONNECTED) return transport_failed;
    }
    DWORD written;
    if (WaitForSingleObject(stop_requested, 0) == WAIT_TIMEOUT && read_hello(pipe.get()) && authorize(pipe.get()) &&
        WriteFile(pipe.get(), accepted, sizeof(accepted) - 1, &written, nullptr) && written == sizeof(accepted) - 1) {
      HANDLE input, output;
      HANDLE self = GetCurrentProcess();
      if (!DuplicateHandle(self, pipe.get(), self, &input, 0, FALSE, DUPLICATE_SAME_ACCESS)) return transport_failed;
      if (!DuplicateHandle(self, pipe.get(), self, &output, 0, FALSE, DUPLICATE_SAME_ACCESS)) {
        CloseHandle(input);
        return transport_failed;
      }
      // The backend owns both duplicates and verifies rollback before returning.
      if (juxic_backend_stdio(input, output)) return rollback_failed;
      if (!FlushFileBuffers(pipe.get())) {
        const DWORD error = GetLastError();
        if (error != ERROR_BROKEN_PIPE && error != ERROR_NO_DATA &&
            error != ERROR_PIPE_NOT_CONNECTED && error != ERROR_OPERATION_ABORTED) return transport_failed;
      }
      if (!DisconnectNamedPipe(pipe.get()) && GetLastError() != ERROR_PIPE_NOT_CONNECTED) return transport_failed;
      return NO_ERROR;
    }
    if (!DisconnectNamedPipe(pipe.get()) && GetLastError() != ERROR_PIPE_NOT_CONNECTED) return transport_failed;
  }
  return NO_ERROR;
}

void WINAPI service_main(DWORD, wchar_t **) {
  Handle stop(CreateEventW(nullptr, TRUE, FALSE, nullptr));
  stop_requested = stop.get();
  status_handle = RegisterServiceCtrlHandlerExW(service_name, control, nullptr);
  if (!status_handle) return;
  report_status(SERVICE_START_PENDING, NO_ERROR, 1);
  Handle ready(CreateEventW(nullptr, TRUE, FALSE, nullptr));
  if (!stop.get() || !ready.get() || !local_system()) {
    report_status(SERVICE_STOPPED, transport_failed);
    return;
  }
  Handle worker(CreateThread(nullptr, 0, serve, ready.get(), 0, nullptr));
  if (!worker.get()) {
    report_status(SERVICE_STOPPED, transport_failed);
    return;
  }
  HANDLE startup[] = {worker.get(), ready.get()};
  if (WaitForMultipleObjects(2, startup, FALSE, INFINITE) == WAIT_OBJECT_0 + 1) {
    report_status(SERVICE_RUNNING);
    HANDLE active[] = {worker.get(), stop.get()};
    if (WaitForMultipleObjects(2, active, FALSE, INFINITE) == WAIT_OBJECT_0 + 1) {
      // Reissue cancellation in case STOP arrived between synchronous calls.
      // Keep the worker alive until the backend has rolled back its session.
      for (DWORD checkpoint = 1;; ++checkpoint) {
        report_status(SERVICE_STOP_PENDING, NO_ERROR, checkpoint);
        CancelSynchronousIo(worker.get());
        if (WaitForSingleObject(worker.get(), 250) == WAIT_OBJECT_0) break;
      }
    }
  }
  DWORD result = transport_failed;
  GetExitCodeThread(worker.get(), &result);
  report_status(SERVICE_STOPPED, result);
}
}

int main() {
  SERVICE_TABLE_ENTRYW table[] = {{const_cast<wchar_t *>(service_name), service_main}, {nullptr, nullptr}};
  return StartServiceCtrlDispatcherW(table) ? 0 : static_cast<int>(GetLastError());
}
