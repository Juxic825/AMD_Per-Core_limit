use std::io::{BufRead, BufReader, Write};
use std::sync::mpsc::{self, Receiver, Sender};

#[derive(Clone, Debug)]
pub struct Reading {
    pub core: usize,
    pub minimum: u8,
    pub highest: u8,
    pub active: Option<f64>,
    pub effective: Option<u32>,
    pub requests: Vec<u8>,
}

pub struct Snapshot {
    pub cores: Vec<Reading>,
    pub idle_disabled: Option<bool>,
}

pub struct Response {
    pub command: String,
    pub result: Result<Snapshot, String>,
}

struct Process {
    input: Box<dyn Write>,
    output: BufReader<Box<dyn std::io::Read>>,
}

impl Process {
    fn launch() -> Result<Self, String> {
        let (input, output) = crate::system_backend::launch()?;
        Ok(Self { input: Box::new(input), output: BufReader::new(Box::new(output)) })
    }

    fn request(&mut self, command: &str) -> Result<Snapshot, String> {
        writeln!(self.input, "{command}").map_err(|e| e.to_string())?;
        let mut snapshot = Snapshot { cores: Vec::new(), idle_disabled: None };
        let header = self.line()?;
        for _ in 0..1024 {
            let line = self.line()?;
            if line == "END" {
                return if header == "OK" { Ok(snapshot) } else { Err(format!("backend: {}", header.strip_prefix("ERR ").unwrap_or(&header))) };
            }
            let fields: Vec<_> = line.split_ascii_whitespace().collect();
            match fields.as_slice() {
                ["CORE", index, min, highest, active, frequency, requests] => {
                    let invalid = || "Invalid backend core data".to_owned();
                    snapshot.cores.push(Reading {
                        core: index.parse().map_err(|_| invalid())?,
                        minimum: min.parse().map_err(|_| invalid())?,
                        highest: highest.parse().map_err(|_| invalid())?,
                        active: active.parse().ok(),
                        effective: frequency.parse().ok(),
                        requests: requests.split(',').map(str::parse).collect::<Result<_, _>>().map_err(|_| invalid())?,
                    });
                }
                ["IDLE", value] => snapshot.idle_disabled = match *value { "0" => Some(false), "1" => Some(true), _ => None },
                _ => return Err("Unexpected backend reply".into()),
            }
        }
        Err("Backend reply exceeds the expected size".into())
    }

    fn line(&mut self) -> Result<String, String> {
        let mut line = String::new();
        if self.output.read_line(&mut line).map_err(|e| e.to_string())? == 0 {
            return Err("Backend exited before replying".into());
        }
        Ok(line.trim_end_matches(['\n', '\r']).to_owned())
    }
}

pub fn start() -> (Sender<String>, Receiver<Response>) {
    let (send, work) = mpsc::channel::<String>();
    let (reply, receive) = mpsc::channel();
    std::thread::spawn(move || {
        let mut process = None;
        while let Ok(command) = work.recv() {
            let mut result = Err("Backend unavailable".into());
            if process.is_none() && command != "quit" {
                match Process::launch() {
                    Ok(child) => process = Some(child),
                    Err(error) => result = Err(error),
                }
            }
            if let Some(active) = &mut process {
                result = active.request(if command == "save" { "read" } else { &command });
                let backend_error = result.as_ref().err().is_some_and(|e| e.starts_with("backend: "));
                if result.is_err() && !backend_error { process = None; }
                if command == "quit" && result.is_ok() {
                    drop(process.take());
                    let _ = crate::system_backend::await_service_stop();
                    let _ = reply.send(Response { command, result });
                    break;
                }
            } else if command == "quit" {
                result = Ok(Snapshot { cores: vec![], idle_disabled: None });
                let _ = reply.send(Response { command, result });
                break;
            }
            if reply.send(Response { command, result }).is_err() { break; }
        }
    });
    (send, receive)
}
