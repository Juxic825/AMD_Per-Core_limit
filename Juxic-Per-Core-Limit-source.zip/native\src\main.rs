#![windows_subsystem = "windows"]

mod backend;
mod preset;
mod settings;
mod system_backend;

mod tray;
mod menu_theme;

use backend::{Reading, Response};
use std::{collections::{BTreeMap, BTreeSet}, ptr::null_mut, sync::mpsc::{Receiver, Sender}};
use windows_sys::Win32::{Foundation::*, Graphics::Gdi::*, System::LibraryLoader::GetModuleHandleW, UI::{Input::KeyboardAndMouse::*, WindowsAndMessaging::*}};

#[link(name = "dwmapi")]
extern "system" {
    fn DwmSetWindowAttribute(hwnd: HWND, attribute: u32, value: *const core::ffi::c_void, size: u32) -> i32;
}

pub(crate) const TITLE: &str = "Juxic Per-Core Limit";
pub(crate) const APP_ICON: *const u16 = 1usize as *const u16;
const FOOTER_HEIGHT: i32 = 58;
const TIMER: usize = 1;
const ROW: i32 = 32;
const TOP: i32 = 116;
const EDIT: u16 = 101;
const EM_SETSEL: u32 = 0x00B1;
const EM_SETLIMITTEXT: u32 = 0x00C5;
const LIGHT: [u32; 6] = [0x001c1611, 0x00736659, 0x00efebe6, 0x00fbf9f7, 0x00f8e8d7, 0x00ffffff];
const DARK: [u32; 6] = [0x00eeeae5, 0x00b9afa5, 0x0047413b, 0x00332c25, 0x00654d33, 0x0028201a];

#[derive(Clone, Copy)]
enum Action {
    Apply, Save, Load, ApplyPreset, Refresh, Idle, Settings, Minimize, Maximize, Close,
    Sort(u8), Select(usize), Edit(usize), Step(usize, i32), ApplyCore(usize), Clear,
}

struct App {
    send: Sender<String>, receive: Receiver<Response>, rows: Vec<Reading>, ranks: BTreeMap<usize, usize>,
    selected: BTreeSet<usize>, drafts: BTreeMap<usize, String>, preset: Option<preset::Preset>,
    anchor: Option<usize>, sort: (u8, u8), scroll: usize, english: bool, idle: Option<bool>,
    pending: usize, ticks: u32, startup: bool, status: String,
    buttons: Vec<(RECT, Action)>, edit: HWND, editing: Option<usize>, batch: String,
    font: HFONT, footer_font: HFONT, instance: HINSTANCE,
    closing: bool, dark: bool, tray: Option<tray::TrayIcon>, edit_background: HBRUSH,
}

impl App {
    fn new(instance: HINSTANCE) -> Self {
        let (send, receive) = backend::start();
        let english = settings::english();
        Self {
            send, receive, rows: vec![], ranks: BTreeMap::new(), selected: BTreeSet::new(), drafts: BTreeMap::new(),
            preset: None, anchor: None, sort: (0, 0), scroll: 0, english, idle: None, pending: 0, ticks: 0,
            startup: std::env::args_os().any(|arg| arg == "--apply-preset-on-start"), status: if english {"Reading cores…"} else {"正在读取核心…"}.into(),
            buttons: vec![], edit: null_mut(), editing: None, batch: String::new(), font: null_mut(), footer_font: null_mut(), instance, closing: false, dark: settings::dark_theme(), tray: None, edit_background: null_mut(),
        }
    }
    fn t(&self, zh: &'static str, en: &'static str) -> &'static str { if self.english { en } else { zh } }
    fn request(&mut self, command: String) {
        if (self.closing && command != "quit") || (self.pending != 0 && command == "read") { return; }
        if self.send.send(command).is_ok() { self.pending += 1; }
        else { self.status = self.t("后端不可用", "Backend unavailable").into(); }
    }
    fn ordered(&self) -> Vec<usize> {
        let mut order: Vec<_> = (0..self.rows.len()).collect();
        if self.sort.1 == 0 { return order; }
        order.sort_by_key(|&index| {
            let r = &self.rows[index];
            let (primary, secondary) = if self.sort.0 == 1 {
                (i32::from(r.highest), i32::from(*r.requests.iter().min().unwrap_or(&0)))
            } else { (*self.ranks.get(&r.core).unwrap_or(&0) as i32, 0) };
            let direction = if self.sort.1 == 1 { 1 } else { -1 };
            (primary * direction, secondary * direction, r.core)
        });
        order
    }
    fn draft(&self, core: usize) -> String {
        if let Some(value) = self.drafts.get(&core) { return value.clone(); }
        self.rows.iter().find(|r| r.core == core).map(|r| format!("{}", r.requests.iter().min().unwrap_or(&0))).unwrap_or_default()
    }
    fn load(&mut self) -> Result<(), String> {
        self.preset = None;
        let preset = preset::load(&self.rows)?;
        for (&core, values) in &preset {
            let d = if values.windows(2).all(|w| w[0] == w[1]) { values[0].to_string() } else { preset::join(values) };
            self.drafts.insert(core, d);
        }
        self.selected = preset.keys().copied().collect();
        self.preset = Some(preset);
        self.status = self.t("已读取预设。点击应用预设写入。", "Preset loaded. Click Apply preset to write it.").into();
        Ok(())
    }
    fn receive(&mut self, response: Response) {
        self.pending = self.pending.saturating_sub(1);
        if response.command == "quit" && response.result.is_err() { self.closing = false; }
        match response.result {
            Err(error) => { if response.command != "read" || self.rows.is_empty() { self.status = error; } },
            Ok(mut snapshot) => {
                if let Some(idle) = snapshot.idle_disabled { self.idle = Some(idle); }
                let first = self.rows.is_empty();
                if !snapshot.cores.is_empty() {
                    snapshot.cores.sort_by_key(|row| row.core);
                    self.rows = snapshot.cores;
                    if first {
                        let mut rank: Vec<_> = self.rows.iter().collect();
                        rank.sort_by_key(|r| (std::cmp::Reverse(r.highest), r.core));
                        self.ranks = rank.iter().enumerate().map(|(i, r)| (r.core, i + 1)).collect();
                        self.status = format!("{} {}", self.rows.len(), self.t("个物理核心", "physical cores"));
                    }
                }
                if response.command.starts_with("apply ") {
                    for target in response.command.split_ascii_whitespace().skip(1) {
                        if let Some(core) = target.split_once('=').and_then(|(core, _)| core.parse::<usize>().ok()) { self.drafts.remove(&core); }
                    }
                    self.status = self.t("已写入并读回确认", "Applied and verified").into();
                } else if response.command == "save" {
                    self.status = match preset::save(&self.rows) {
                        Ok(()) => self.t("已保存 CppcPreset.txt", "Saved CppcPreset.txt").into(),
                        Err(error) => error,
                    };
                } else if response.command == "idle-toggle" {
                    self.status = self.t("已更新处理器闲置设置", "Processor idle policy updated").into();
                } else if response.command == "restore" {
                    self.drafts.clear();
                    self.status = self.t("已停止限制，交由系统管理", "Frequency limits cleared. Windows is in control.").into();
                    self.request("read".into());
                }
                if first && self.startup && !self.rows.is_empty() {
                    self.startup = false;
                    match self.load() {
                        Ok(()) => self.request(preset::command(self.preset.as_ref().unwrap())),
                        Err(error) => self.status = error,
                    }
                }
            }
        }
    }
    unsafe fn finish_edit(&mut self) {
        if self.edit.is_null() { return; }
        let h = self.edit;
        let mut text = [0u16; 40];
        let n = GetWindowTextW(h, text.as_mut_ptr(), text.len() as i32);
        let value = String::from_utf16_lossy(&text[..n.max(0) as usize]);
        self.edit = null_mut();
        if let Some(core) = self.editing.take() { self.drafts.insert(core, value); } else { self.batch = value; }
        DestroyWindow(h);
    }
    unsafe fn open_edit(&mut self, hwnd: HWND, rect: RECT, core: Option<usize>) {
        let value = core.map(|id| self.draft(id)).unwrap_or_else(|| self.batch.clone());
        self.editing = core;
        self.edit = CreateWindowExW(WS_EX_CLIENTEDGE, w("EDIT").as_ptr(), w(&value).as_ptr(), WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL as u32,
            rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, hwnd, EDIT as usize as HMENU, self.instance, null_mut());
        if !self.edit.is_null() {
            SendMessageW(self.edit, WM_SETFONT, self.font as usize, 1);
            SendMessageW(self.edit, EM_SETLIMITTEXT, 16, 0);
            SendMessageW(self.edit, EM_SETSEL, 0, -1);
            SetFocus(self.edit);
        }
    }
    unsafe fn action(&mut self, hwnd: HWND, hit: Action, rect: RECT) {
        self.finish_edit();
        match hit {
            Action::Edit(core) => self.open_edit(hwnd, rect, Some(core)),
            Action::Select(core) => {
                let ctrl = GetKeyState(VK_CONTROL as i32) < 0;
                let shift = GetKeyState(VK_SHIFT as i32) < 0;
                if shift {
                    let order: Vec<_> = self.ordered().iter().map(|&i| self.rows[i].core).collect();
                    let a = order.iter().position(|&id| id == self.anchor.unwrap_or(core));
                    let b = order.iter().position(|&id| id == core);
                    if !ctrl { self.selected.clear(); }
                    if let (Some(a), Some(b)) = (a, b) { self.selected.extend(order[a.min(b)..=a.max(b)].iter().copied()); }
                } else {
                    if !ctrl { self.selected.clear(); }
                    if !self.selected.insert(core) && ctrl { self.selected.remove(&core); }
                    self.anchor = Some(core);
                }
            }
            Action::Clear => { self.selected.clear(); self.anchor = None; }
            Action::Sort(col) => { self.sort = (col, if self.sort.0 == col { (self.sort.1 + 1) % 3 } else { 1 }); self.scroll = 0; }
            Action::Step(core, delta) => if let Some(r) = self.rows.iter().find(|r| r.core == core) {
                if r.minimum <= r.highest {
                    let current = self.draft(core).parse::<i32>().unwrap_or(i32::from(*r.requests.iter().min().unwrap_or(&r.minimum)));
                    self.drafts.insert(core, (current + delta).clamp(r.minimum.into(), r.highest.into()).to_string());
                }
            },
            Action::ApplyCore(core) => {
                let value = self.draft(core);
                if valid_perf(&value) {
                    let value = value.split(',').map(str::trim).collect::<Vec<_>>().join(",");
                    self.request(format!("apply {core}={value}"));
                }
                else { self.status = self.t("请输入有效 Perf 数字", "Enter a valid Perf value").into(); }
            }
            Action::Apply => {
                let value = self.batch.trim();
                if self.selected.is_empty() { self.status = self.t("请先选择核心", "Select at least one core").into(); }
                else if value.parse::<u8>().is_ok_and(|n| n > 0) || value.eq_ignore_ascii_case("a") {
                    self.request(format!("apply {}", self.selected.iter().map(|core| format!("{core}={value}")).collect::<Vec<_>>().join(" ")));
                } else { self.status = self.t("请输入 1–255 或 A", "Enter 1–255 or A").into(); }
            }
            Action::Refresh => { self.request("read".into()); }
            Action::Idle => self.request("idle-toggle".into()),
            Action::Save if self.rows.is_empty() => { self.status = self.t("暂无核心读数", "No core readings yet").into(); }
            Action::Save => self.request("save".into()),
            Action::Load => if let Err(error) = self.load() { self.status = error; },
            Action::ApplyPreset => if let Some(preset) = &self.preset { self.request(preset::command(preset)); },
            Action::Settings => self.menu(hwnd),
            Action::Minimize => { ShowWindow(hwnd, SW_MINIMIZE); }
            Action::Maximize => { ShowWindow(hwnd, if IsZoomed(hwnd) != 0 { SW_RESTORE } else { SW_MAXIMIZE }); }
            Action::Close => { PostMessageW(hwnd, WM_CLOSE, 0, 0); }
        }
        InvalidateRect(hwnd, null_mut(), 0);
    }
    unsafe fn update_theme(&mut self, hwnd: HWND) {
        if !self.edit_background.is_null() { DeleteObject(self.edit_background); }
        self.edit_background = CreateSolidBrush(if self.dark { DARK[5] } else { LIGHT[5] });
        let dark = i32::from(self.dark);
        DwmSetWindowAttribute(hwnd, 20, (&dark as *const i32).cast(), 4);
        InvalidateRect(hwnd, null_mut(), 1);
    }
    unsafe fn hide_to_tray(&mut self, hwnd: HWND) -> bool {
        if self.tray.as_mut().is_some_and(|icon| icon.add()) {
            self.finish_edit();
            ShowWindow(hwnd, SW_HIDE);
            true
        } else {
            false
        }
    }
    unsafe fn show_from_tray(&mut self, hwnd: HWND) {
        ShowWindow(hwnd, SW_RESTORE);
        SetForegroundWindow(hwnd);
        if let Some(icon) = &mut self.tray { icon.remove(); }
        self.request("read".into());
    }
    fn quit(&mut self) {
        if self.closing { return; }
        self.startup = false;
        self.closing = true;
        self.status = self.t("正在恢复本次运行的设置…", "Restoring session settings…").into();
        self.request("quit".into());
    }
    unsafe fn menu(&mut self, hwnd: HWND) {
        let popup = CreatePopupMenu();
        if popup.is_null() { return; }
        let login = settings::startup_enabled().unwrap_or(false);
        let silent = login && settings::silent_startup().unwrap_or(false);
        let startup = CreatePopupMenu();
        let theme = CreatePopupMenu();
        let lang = CreatePopupMenu();
        let mut renderer = menu_theme::MenuThemeRenderer::new(menu_theme::MenuTheme::from_dark(self.dark));
        for menu in [popup, startup, theme, lang] { renderer.apply_background(menu); }
        let mut item = |menu, id, text: &str, flags| renderer.append(menu, id, text, flags);
        item(startup, 1, self.t("开机自启", "Start at sign-in"), if login { MF_CHECKED } else { 0 });
        item(startup, 5, self.t("静默自启", "Start silently"), if silent { MF_CHECKED } else if !login { MF_GRAYED } else { 0 });
        item(startup, 6, self.t("关闭时缩小到托盘", "Minimize to tray on close"), if settings::close_to_tray() == Some(true) { MF_CHECKED } else { 0 });
        item(theme, 7, self.t("亮色主题", "Light theme"), if !self.dark { MF_CHECKED } else { 0 });
        item(theme, 8, self.t("暗色主题", "Dark theme"), if self.dark { MF_CHECKED } else { 0 });
        item(lang, 2, "简体中文", if !self.english { MF_CHECKED } else { 0 });
        item(lang, 3, "English", if self.english { MF_CHECKED } else { 0 });
        renderer.append_submenu(popup, startup, self.t("启动与托盘", "Startup and tray"));
        renderer.append_submenu(popup, theme, self.t("主题", "Theme"));
        renderer.append_submenu(popup, lang, self.t("语言", "Language"));
        let mut pt = POINT { x: 0, y: 0 };
        GetCursorPos(&mut pt);
        let command = menu_theme::with_renderer(&renderer, ||
            TrackPopupMenu(popup, TPM_RETURNCMD | TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwnd, null_mut()));
        DestroyMenu(popup);
        let result = match command {
            1 => settings::set_startup(!login),
            2 | 3 => settings::set_english(command == 3).map(|()| { self.english = command == 3; }),
            5 if login => settings::set_silent_startup(!silent),
            6 => settings::set_close_to_tray(Some(settings::close_to_tray() != Some(true))),
            7 | 8 => settings::set_dark_theme(command == 8).map(|()| {
                self.dark = command == 8;
                self.update_theme(hwnd);
            }),
            _ => return,
        };
        self.status = match result { Ok(()) => self.t("设置已保存", "Settings saved").into(), Err(e) => e };
    }
}

fn valid_perf(value: &str) -> bool {
    value.split(',').all(|part| part.trim().parse::<u8>().is_ok_and(|n| n > 0))
}
fn w(s: &str) -> Vec<u16> { s.encode_utf16().chain(Some(0)).collect() }
fn bounds(left: i32, top: i32, right: i32, bottom: i32) -> RECT { RECT {left,top,right,bottom} }
fn inside(r: &RECT, x: i32, y: i32) -> bool { x >= r.left && x < r.right && y >= r.top && y < r.bottom }
unsafe fn fill(dc: HDC, r: &RECT, color: u32) {
    let brush = CreateSolidBrush(color);
    FillRect(dc, r, brush);
    DeleteObject(brush);
}
unsafe fn label(dc: HDC, r: RECT, text: &str, color: u32, centered: bool) {
    SetTextColor(dc, color);
    let mut r = r;
    let mut txt = w(text);
    DrawTextW(dc, txt.as_mut_ptr(), (txt.len() - 1) as i32, &mut r,
        DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS | DT_NOPREFIX | if centered { DT_CENTER } else { DT_LEFT });
}
unsafe fn button(dc: HDC, hits: &mut Vec<(RECT, Action)>, r: RECT, text: &str, action: Action, active: bool, colors: &[u32; 6]) {
    fill(dc, &r, colors[2]);
    fill(dc, &bounds(r.left + 1, r.top + 1, r.right - 1, r.bottom - 1), colors[3]);
    label(dc, r, text, if active { colors[0] } else { colors[1] }, true);
    if active { hits.push((r, action)); }
}

unsafe fn paint(hwnd: HWND, app: &mut App) {
    let colors = if app.dark { &DARK } else { &LIGHT };
    let mut ps: PAINTSTRUCT = std::mem::zeroed();
    let dc = BeginPaint(hwnd, &mut ps);
    let mut client: RECT = std::mem::zeroed();
    GetClientRect(hwnd, &mut client);
    let (width, height) = (client.right, client.bottom);
    if width <= 0 || height <= 0 { EndPaint(hwnd, &ps); return; }
    let buffer = CreateCompatibleDC(dc);
    let bitmap = CreateCompatibleBitmap(dc, width, height);
    let old = SelectObject(buffer, bitmap);
    SelectObject(buffer, app.font);
    SetBkMode(buffer, TRANSPARENT as i32);
    fill(buffer, &client, colors[5]);
    let mut hits = Vec::new();
    fill(buffer, &bounds(0, 0, width, 35), colors[3]);
    label(buffer, bounds(14, 0, width - 172, 35), TITLE, colors[0], false);
    for (i, (caption, action)) in [("⚙", Action::Settings), ("−", Action::Minimize), ("□", Action::Maximize), ("×", Action::Close)].iter().enumerate() {
        let x = width - 172 + i as i32 * 42;
        button(buffer, &mut hits, bounds(x, 3, x + 40, 32), caption, *action, true, colors);
    }
    let english = app.english;
    let t = |zh,en| if english { en } else { zh };
    label(buffer, bounds(14, 37, if english { 255 } else { 154 }, 62), t("AMD逐核限制频率", "AMD Per-Core Frequency Limit"), colors[0], false);
    label(buffer, bounds(if english { 260 } else { 160 }, 37, width - 12, 62), t("Shift 连选 · Ctrl 点选 · Ctrl+A 全选 · 点击空白处清空", "Shift selects ranges · Ctrl toggles · Ctrl+A selects all"), colors[1], false);
    label(buffer, bounds(14, 65, 74, 95), "MaxPerf", colors[0], false);
    let minimum = app.rows.iter().filter(|r| app.selected.is_empty() || app.selected.contains(&r.core)).map(|r| r.minimum).max();
    let hint = minimum.map(|n| format!("{n}-A")).unwrap_or_default();
    let batch = bounds(78, 65, 140, 95);
    fill(buffer, &batch, colors[2]);
    fill(buffer, &bounds(79, 66, 139, 94), colors[5]);
    label(buffer, bounds(85, 65, 139, 95), if app.batch.is_empty() { &hint } else { &app.batch }, if app.batch.is_empty() { colors[1] } else { colors[0] }, false);
    let mut x = 148;
    let control_width = if app.english { 92 } else { 78 };
    for (caption, action, active) in [
        (t("应用", "Apply"), Action::Apply, true), (t("保存预设", "Save preset"), Action::Save, true),
        (t("读取预设", "Load preset"), Action::Load, true), (t("应用预设", "Apply preset"), Action::ApplyPreset, app.preset.is_some()),
        (t("刷新读数", "Refresh"), Action::Refresh, true), (if app.idle == Some(true) {t("启用闲置", "Enable idle")} else {t("禁用闲置", "Disable idle")}, Action::Idle, true),
    ] {
        button(buffer, &mut hits, bounds(x, 65, x + control_width, 95), caption, action, active, colors);
        x += control_width + 4;
    }
    let cols = [14, width * 25 / 100, width * 44 / 100, width * 67 / 100, width - 14];
    fill(buffer, &bounds(cols[0], TOP - 16, cols[4], TOP + 14), colors[2]);
    let captions = [t("核心", "Core"), t("核心频率/有效频率", "Core / effective MHz"), "MaxPerf/CurPerf", t("逐核限制", "Per-core limit")];
    for (i, caption) in captions.iter().enumerate() {
        let col = if i == 0 { Some(0) } else if i == 2 { Some(1) } else { None };
        let arrow = if col == Some(app.sort.0) { match app.sort.1 { 1 => "  ▲", 2 => "  ▼", _ => "" } } else { "" };
        label(buffer, bounds(cols[i] + 8, TOP - 16, cols[i + 1], TOP + 14), &format!("{caption}{arrow}"), colors[0], false);
        if let Some(col) = col { hits.push((bounds(cols[i], TOP - 16, cols[i + 1], TOP + 14), Action::Sort(col))); }
    }
    let visible = ((height - FOOTER_HEIGHT - TOP - 14) / ROW).max(0) as usize;
    app.scroll = app.scroll.min(app.rows.len().saturating_sub(visible));
    let order = app.ordered();
    for (offset, index) in order.iter().skip(app.scroll).take(visible).enumerate() {
        let row = &app.rows[*index];
        let y = TOP + 14 + offset as i32 * ROW;
        let r = bounds(cols[0], y, cols[4], y + ROW);
        fill(buffer, &r, if app.selected.contains(&row.core) { colors[4] } else if offset % 2 == 0 {colors[5]} else {colors[3]});
        hits.push((r, Action::Select(row.core)));
        label(buffer, bounds(cols[0] + 8, y, cols[1], y + ROW), &format!("Core{}(Perf #{})", row.core, app.ranks.get(&row.core).unwrap_or(&0)), colors[0], false);
        let active = row.active.map(|mhz| format!("{mhz:.1}")).unwrap_or_else(|| "—".into());
        let effective = row.effective.map(|mhz| mhz.to_string()).unwrap_or_else(|| "—".into());
        label(buffer, bounds(cols[1] + 8, y, cols[2], y + ROW), &format!("{active}/{effective} MHz"), colors[0], false);
        let mut pairs: Vec<_> = row.requests.iter().map(|v| format!("{}/{v}", row.highest)).collect();
        pairs.dedup();
        label(buffer, bounds(cols[2] + 8, y, cols[3], y + ROW), &pairs.join(" · "), colors[0], false);
        let x = cols[3] + 4;
        let input = bounds(x, y + 3, x + 65, y + ROW - 3);
        button(buffer, &mut hits, input, &app.draft(row.core), Action::Edit(row.core), true, colors);
        button(buffer, &mut hits, bounds(x + 69, y + 3, x + 94, y + ROW - 3), "+", Action::Step(row.core, 1), true, colors);
        button(buffer, &mut hits, bounds(x + 97, y + 3, x + 122, y + ROW - 3), "−", Action::Step(row.core, -1), true, colors);
        button(buffer, &mut hits, bounds(x + 125, y + 3, x + 180, y + ROW - 3), t("应用", "Apply"), Action::ApplyCore(row.core), true, colors);
    }
    let footer = height - FOOTER_HEIGHT;
    fill(buffer, &bounds(0, footer, width, height), colors[3]);
    let status = format!("{}  ·  {} {}", app.status, app.selected.len(), t("核已选", "selected"));
    label(buffer, bounds(14, footer, width - 12, footer + 23), &status, colors[1], false);
    SelectObject(buffer, app.footer_font);
    SetTextColor(buffer, colors[1]);
    let mut credit = w(t("抖音:记性差\n仅供学习交流 禁止商用盗用", "Douyin: 记性差\nFor learning and discussion only. No commercial use or unauthorized copying."));
    let mut rect = bounds(12, footer + 20, width - 13, height - 8);
    DrawTextW(buffer, credit.as_mut_ptr(), -1, &mut rect, DT_RIGHT | DT_NOPREFIX);
    app.buttons = hits;
    BitBlt(dc, 0, 0, width, height, buffer, 0, 0, SRCCOPY);
    SelectObject(buffer, old);
    DeleteObject(bitmap);
    DeleteDC(buffer);
    EndPaint(hwnd, &ps);
}

unsafe extern "system" fn wnd(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    if let Some(result) = menu_theme::handle_message(msg, lp) { return result; }
    if msg == WM_NCCREATE {
        let create = &*(lp as *const CREATESTRUCTW);
        SetWindowLongPtrW(hwnd, GWLP_USERDATA, create.lpCreateParams as isize);
    }
    let state = GetWindowLongPtrW(hwnd, GWLP_USERDATA) as *mut App;
    if state.is_null() { return DefWindowProcW(hwnd, msg, wp, lp); }
    let app = &mut *state;
    if app.tray.as_mut().is_some_and(|icon| icon.taskbar_created(msg)) && IsWindowVisible(hwnd) == 0 {
        if !app.hide_to_tray(hwnd) { app.show_from_tray(hwnd); }
        return 0;
    }
    match msg {
        WM_CREATE => {
            app.font = CreateFontW(-16, 0, 0, 0, FW_NORMAL as i32, 0, 0, 0, DEFAULT_CHARSET as u32, 0, 0, CLEARTYPE_QUALITY as u32, 0, w("Segoe UI").as_ptr());
            app.footer_font = CreateFontW(-11, 0, 0, 0, FW_NORMAL as i32, 0, 0, 0, DEFAULT_CHARSET as u32, 0, 0, CLEARTYPE_QUALITY as u32, 0, w("Segoe UI").as_ptr());
            app.tray = Some(tray::TrayIcon::new(hwnd, app.instance));
            app.update_theme(hwnd);
            let small_round = 3u32;
            DwmSetWindowAttribute(hwnd, 33, (&small_round as *const u32).cast(), 4);
            SetTimer(hwnd, TIMER, 80, None);
            app.request("read".into());
            0
        }
        WM_GETMINMAXINFO => {
            let info = &mut *(lp as *mut MINMAXINFO);
            info.ptMinTrackSize = POINT {x: 750, y: 350}; 0
        }
        WM_NCCALCSIZE => 0,
        WM_NCPAINT | 0x00AE | 0x00AF => 0,
        WM_NCACTIVATE => DefWindowProcW(hwnd, msg, wp, -1),
        WM_NCHITTEST => {
            let mut p = POINT {x: lp as i16 as i32, y: (lp >> 16) as i16 as i32};
            ScreenToClient(hwnd, &mut p);
            let mut r: RECT = std::mem::zeroed(); GetClientRect(hwnd, &mut r);
            let (l,t,rr,b) = (p.x < 6, p.y < 6, p.x >= r.right - 6, p.y >= r.bottom - 6);
            let hit = if IsZoomed(hwnd) == 0 && (l || t || rr || b) {
                match (l,t,rr,b) { (true,true,_,_)=>HTTOPLEFT, (_,true,true,_)=>HTTOPRIGHT, (true,_,_,true)=>HTBOTTOMLEFT, (_,_,true,true)=>HTBOTTOMRIGHT, (true,_,_,_)=>HTLEFT, (_,true,_,_)=>HTTOP, (_,_,true,_)=>HTRIGHT, _=>HTBOTTOM }
            } else if p.y < 35 && p.x < r.right - 172 { HTCAPTION } else { HTCLIENT };
            hit as isize
        }
        WM_PAINT => { paint(hwnd, app); 0 }
        WM_TIMER if wp == TIMER => {
            let mut update = false;
            while let Ok(reply) = app.receive.try_recv() {
                if reply.command == "quit" && reply.result.is_ok() {
                    DestroyWindow(hwnd);
                    return 0;
                }
                let report_hidden_error = reply.result.is_err()
                    && matches!(reply.command.as_str(), "quit" | "restore")
                    && IsWindowVisible(hwnd) == 0;
                app.receive(reply);
                if report_hidden_error { app.show_from_tray(hwnd); }
                update = true;
            }
            app.ticks = (app.ticks + 1).min(12);
            if !app.closing && IsWindowVisible(hwnd) != 0 && app.ticks >= 12 && app.pending == 0 { app.ticks = 0; app.request("read".into()); }
            if update { InvalidateRect(hwnd, null_mut(), 0); }
            0
        }
        WM_LBUTTONDOWN => {
            let (x,y) = (lp as i16 as i32, (lp >> 16) as i16 as i32);
            if (78..140).contains(&x) && (65..95).contains(&y) {
                app.finish_edit(); app.open_edit(hwnd, bounds(78,65,140,95), None);
            } else if let Some((rect, action)) = app.buttons.iter().rev().find(|(r, _)| inside(r,x,y)).copied() {
                app.action(hwnd, action, rect);
            } else { app.action(hwnd, Action::Clear, bounds(0,0,0,0)); }
            0
        }
        WM_MOUSEWHEEL => {
            let mut p = POINT {x: lp as i16 as i32, y: (lp >> 16) as i16 as i32};
            ScreenToClient(hwnd, &mut p);
            let delta = ((wp >> 16) as i16 as i32) / 120;
            if let Some((r, Action::Edit(core))) = app.buttons.iter().rev().find(|(r,a)| matches!(a,Action::Edit(_)) && inside(r,p.x,p.y)).copied() {
                app.action(hwnd, Action::Step(core, delta * 3), r);
            } else { app.finish_edit(); app.scroll = app.scroll.saturating_add_signed(-(delta as isize) * 3); InvalidateRect(hwnd, null_mut(), 0); }
            0
        }
        WM_KEYDOWN if wp == b'A' as usize && GetKeyState(VK_CONTROL as i32) < 0 => {
            app.selected = app.rows.iter().map(|r| r.core).collect(); InvalidateRect(hwnd, null_mut(), 0); 0
        }
        WM_SIZE => {
            app.finish_edit();
            let corner = if wp as u32 == SIZE_MAXIMIZED { 1u32 } else { 3u32 };
            if DwmSetWindowAttribute(hwnd, 33, (&corner as *const u32).cast(), 4) < 0 && wp as u32 != SIZE_MINIMIZED {
                let mut window = std::mem::zeroed::<RECT>();
                if GetWindowRect(hwnd, &mut window) != 0 {
                    let region = if wp as u32 == SIZE_MAXIMIZED { null_mut() } else {
                        CreateRoundRectRgn(0, 0, window.right - window.left, window.bottom - window.top, 9, 9)
                    };
                    if SetWindowRgn(hwnd, region, 1) == 0 && !region.is_null() { DeleteObject(region); }
                }
            }
            InvalidateRect(hwnd, null_mut(), 0);
            0
        }
        WM_CTLCOLOREDIT => {
            let colors = if app.dark { &DARK } else { &LIGHT };
            SetTextColor(wp as HDC, colors[0]);
            SetBkColor(wp as HDC, colors[5]);
            app.edit_background as LRESULT
        }
        tray::CALLBACK_MESSAGE => {
            match app.tray.as_ref().and_then(|icon| icon.action(lp)) {
                Some(tray::TrayEvent::Open) => app.show_from_tray(hwnd),
                Some(tray::TrayEvent::Menu) => match tray::show_menu(hwnd, app.english, app.dark) {
                    Some(tray::TrayCommand::Open) => app.show_from_tray(hwnd),
                    Some(tray::TrayCommand::Exit) => app.quit(),
                    Some(tray::TrayCommand::Restore) => {
                        app.startup = false;
                        app.request("restore".into());
                    }
                    None => {}
                },
                None => {}
            }
            0
        }
        WM_CLOSE => {
            if app.closing { return 0; }
            let choice = settings::close_to_tray().map(|hide| (hide, false))
                .or_else(|| tray::prompt_close(hwnd, app.english));
            if let Some((hide, remember)) = choice {
                if remember {
                    if let Err(error) = settings::set_close_to_tray(Some(hide)) { app.status = error; }
                }
                if !hide || !app.hide_to_tray(hwnd) { app.quit(); }
                InvalidateRect(hwnd, null_mut(), 0);
            }
            0
        }
        WM_DESTROY => {
            KillTimer(hwnd, TIMER);
            if let Some(icon) = &mut app.tray { icon.remove(); }
            if !app.edit_background.is_null() { DeleteObject(app.edit_background); }
            if !app.font.is_null() { DeleteObject(app.font); }
            if !app.footer_font.is_null() { DeleteObject(app.footer_font); }
            PostQuitMessage(0); 0
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

fn main() {
    let args: Vec<_> = std::env::args_os().collect();
    if args.iter().any(|arg| arg == "--uninstall-service") {
        if let Err(error) = system_backend::uninstall() {
            unsafe { MessageBoxW(null_mut(), w(&error).as_ptr(), w(TITLE).as_ptr(), MB_ICONERROR); }
        }
        return;
    }
    let silent = args.iter().any(|arg| arg == "--apply-preset-on-start") && args.iter().any(|arg| arg == "--silent-startup");
    unsafe {
        let instance = GetModuleHandleW(null_mut());
        let class = w("JuxicPerCoreLimitWindow");
        let wc = WNDCLASSW { style: CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS, lpfnWndProc: Some(wnd), hInstance: instance,
            hCursor: LoadCursorW(null_mut(), IDC_ARROW), hIcon: LoadIconW(instance, APP_ICON),
            lpszClassName: class.as_ptr(), ..std::mem::zeroed() };
        if RegisterClassW(&wc) == 0 { return; }
        let state = Box::into_raw(Box::new(App::new(instance)));
        let h = CreateWindowExW(0, class.as_ptr(), w(TITLE).as_ptr(), WS_POPUP | WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_CLIPCHILDREN,
            CW_USEDEFAULT, CW_USEDEFAULT, 860, 705, null_mut(), null_mut(), instance, state.cast());
        if !h.is_null() {
            if !silent || !(*state).hide_to_tray(h) { ShowWindow(h, SW_SHOW); }
            let mut msg: MSG = std::mem::zeroed();
            while GetMessageW(&mut msg, null_mut(), 0, 0) > 0 {
                if msg.message == WM_KEYDOWN && msg.wParam == VK_RETURN as usize && msg.hwnd != h {
                    (*state).finish_edit(); InvalidateRect(h, null_mut(), 0); continue;
                }
                TranslateMessage(&msg); DispatchMessageW(&msg);
            }
        }
        drop(Box::from_raw(state));
    }
}
