//! Owner-drawn Win32 popup menus with explicit light/dark palettes.
//!
//! Integration: keep `MenuTheme` alive until after `DestroyMenu`; call
//! `theme.append(menu, id, label, flags)` instead of `AppendMenuW` for text
//! rows, and `theme.append_submenu(parent, submenu, label)` for native nested
//! menus. In the window procedure, forward `WM_MEASUREITEM`'s
//! `MEASUREITEMSTRUCT` and `WM_DRAWITEM`'s `DRAWITEMSTRUCT` to
//! `theme.measure(item)` / `theme.draw(item)`. Return 1 when handled, else 0.
//! Keep normal menu flags (MF_CHECKED, MF_GRAYED, MF_SEPARATOR, MF_POPUP).
//! Native menu tracking and keyboard/input behavior remain Win32's.

use std::cell::Cell;
use std::collections::HashMap;
use std::mem::size_of;
use windows_sys::Win32::Foundation::{COLORREF, RECT};
use windows_sys::Win32::Graphics::Gdi::{
    CreateSolidBrush, DeleteObject, DrawTextW, FillRect, GetStockObject, SelectObject,
    SetBkMode, SetTextColor, DEFAULT_GUI_FONT, DT_LEFT, DT_SINGLELINE, DT_VCENTER,
    TRANSPARENT,
};
use windows_sys::Win32::UI::WindowsAndMessaging::{
    AppendMenuW, InsertMenuItemW, GetMenuItemCount, MF_SEPARATOR, MIIM_DATA, MIIM_FTYPE,
    MIIM_ID, MIIM_STRING, MIIM_SUBMENU, MIIM_STATE, MFT_OWNERDRAW, MENUINFO, MIM_BACKGROUND,
    SetMenuInfo, MENUITEMINFOW,
};
use windows_sys::Win32::UI::Controls::{
    ODS_CHECKED, ODS_DISABLED, ODS_GRAYED, ODS_FOCUS, ODS_SELECTED, ODT_MENU, MEASUREITEMSTRUCT, DRAWITEMSTRUCT,
};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum MenuTheme { Light, Dark }

impl MenuTheme {
    pub const fn from_dark(dark: bool) -> Self { if dark { Self::Dark } else { Self::Light } }
}

thread_local! { static ACTIVE_RENDERER: Cell<*const MenuThemeRenderer> = const { Cell::new(std::ptr::null()) }; }

/// Temporarily route menu owner-draw messages to `renderer` on this UI thread.
/// The prior renderer is restored even if `callback` unwinds.
pub fn with_renderer<R>(renderer: &MenuThemeRenderer, callback: impl FnOnce() -> R) -> R {
    struct Restore(*const MenuThemeRenderer);
    impl Drop for Restore {
        fn drop(&mut self) { ACTIVE_RENDERER.with(|slot| slot.set(self.0)); }
    }
    ACTIVE_RENDERER.with(|slot| {
        let previous = slot.replace(renderer as *const _);
        let _restore = Restore(previous);
        callback()
    })
}

/// Handle owner-draw menu messages while `with_renderer` is active.
/// Returns Some(1) when handled and None otherwise.
pub unsafe fn handle_message(msg: u32, lp: isize) -> Option<isize> {
    use windows_sys::Win32::UI::WindowsAndMessaging::{WM_DRAWITEM, WM_MEASUREITEM};
    ACTIVE_RENDERER.with(|slot| {
        let renderer = slot.get();
        if renderer.is_null() || lp == 0 { return None; }
        match msg {
            WM_MEASUREITEM => ((*renderer).measure(&mut *(lp as *mut MEASUREITEMSTRUCT))).then_some(1),
            WM_DRAWITEM => ((*renderer).draw(&*(lp as *const DRAWITEMSTRUCT))).then_some(1),
            _ => None,
        }
    })
}

struct Row { text: Vec<u16>, submenu: bool }

/// Owns owner-draw row data. Must outlive its HMENU tree.
pub struct MenuThemeRenderer {
    theme: MenuTheme,
    rows: HashMap<usize, Box<Row>>,
    brushes: Vec<windows_sys::Win32::Graphics::Gdi::HBRUSH>,
}

impl MenuThemeRenderer {
    pub fn new(theme: MenuTheme) -> Self { Self { theme, rows: HashMap::new(), brushes: Vec::new() } }

    /// Apply the palette to the menu surface behind items (including padding).
    /// The renderer owns the brush and must outlive menus using it.
    pub unsafe fn apply_background(&mut self, menu: windows_sys::Win32::UI::WindowsAndMessaging::HMENU) {
        let color = match self.theme { MenuTheme::Dark => rgb(32,32,32), MenuTheme::Light => rgb(255,255,255) };
        let brush = CreateSolidBrush(color);
        if brush.is_null() { return; }
        let mut info: MENUINFO = std::mem::zeroed();
        info.cbSize = size_of::<MENUINFO>() as u32;
        info.fMask = MIM_BACKGROUND;
        info.hbrBack = brush;
        if SetMenuInfo(menu, &info) != 0 { self.brushes.push(brush); }
        else { DeleteObject(brush); }
    }

    /// Append an owner-drawn text/check/radio item; include MF_POPUP only for submenu rows.
    pub unsafe fn append(&mut self, menu: windows_sys::Win32::UI::WindowsAndMessaging::HMENU,
                         id: usize, label: &str, flags: u32) -> bool {
        if flags & MF_SEPARATOR != 0 {
            // Drawn as a native separator; background comes from apply_background.
            return AppendMenuW(menu, MF_SEPARATOR, 0, std::ptr::null()) != 0;
        }
        self.append_impl(menu, id, label, flags, false)
    }

    /// Append a native submenu. Win32 retains submenu navigation and input.
    pub unsafe fn append_submenu(&mut self,
        menu: windows_sys::Win32::UI::WindowsAndMessaging::HMENU,
        submenu: windows_sys::Win32::UI::WindowsAndMessaging::HMENU, label: &str) -> bool {
        self.append_impl(menu, submenu as usize, label,
            windows_sys::Win32::UI::WindowsAndMessaging::MF_POPUP, true)
    }

    unsafe fn append_impl(&mut self, menu: windows_sys::Win32::UI::WindowsAndMessaging::HMENU,
                          id: usize, label: &str, flags: u32, submenu: bool) -> bool {
        let mut row = Box::new(Row { text: label.encode_utf16().chain(Some(0)).collect(), submenu });
        let data = (&mut *row as *mut Row) as usize;
        let result = if submenu {
            let mut info: MENUITEMINFOW = std::mem::zeroed();
            info.cbSize = size_of::<MENUITEMINFOW>() as u32;
            info.fMask = MIIM_FTYPE | MIIM_ID | MIIM_SUBMENU | MIIM_DATA;
            info.fType = MFT_OWNERDRAW;
            info.wID = id as u32;
            info.hSubMenu = id as _;
            info.dwItemData = data;
            InsertMenuItemW(menu, GetMenuItemCount(menu) as u32, 1, &info)
        } else {
            let mut info: MENUITEMINFOW = std::mem::zeroed();
            info.cbSize = size_of::<MENUITEMINFOW>() as u32;
            info.fMask = MIIM_FTYPE | MIIM_ID | MIIM_STRING | MIIM_DATA | MIIM_STATE;
            info.fType = MFT_OWNERDRAW;
            info.wID = id as u32;
            info.dwTypeData = row.text.as_mut_ptr();
            info.dwItemData = data;
            // Translate MF_* flags to their MENUITEMINFO state equivalents.
            info.fState = if flags & 0x0008 != 0 { 0x0008 } else { 0 };
            if flags & 0x0001 != 0 { info.fState |= 0x0003; }
            else if flags & 0x0002 != 0 { info.fState |= 0x0003; }
            InsertMenuItemW(menu, GetMenuItemCount(menu) as u32, 1, &info)
        } != 0;
        if result { self.rows.insert(data, row); }
        result
    }

    /// Handle a menu WM_MEASUREITEM structure; false if it is not a menu row.
    pub unsafe fn measure(&self, item: &mut MEASUREITEMSTRUCT) -> bool {
        if item.CtlType != ODT_MENU { return false; }
        let Some(row) = self.rows.get(&item.itemData) else { return false; };
        let hdc = windows_sys::Win32::Graphics::Gdi::CreateCompatibleDC(std::ptr::null_mut());
        if hdc.is_null() { return false; }
        let font = GetStockObject(DEFAULT_GUI_FONT as i32);
        let old = SelectObject(hdc, font);
        let mut rect = RECT { left: 0, top: 0, right: 0, bottom: 0 };
        DrawTextW(hdc, row.text.as_ptr(), -1, &mut rect, DT_LEFT | DT_SINGLELINE | DT_VCENTER | 0x00000400);
        SelectObject(hdc, old);
        windows_sys::Win32::Graphics::Gdi::DeleteDC(hdc);
        item.itemWidth = (rect.right.max(0) as u32).saturating_add(68);
        item.itemHeight = 26;
        true
    }

    /// Handle a menu WM_DRAWITEM structure.
    pub unsafe fn draw(&self, item: &DRAWITEMSTRUCT) -> bool {
        if item.CtlType != ODT_MENU { return false; }
        let Some(row) = self.rows.get(&item.itemData) else { return false; };
        let (bg, fg, muted, accent) = match self.theme {
            MenuTheme::Dark => (rgb(32,32,32), rgb(240,240,240), rgb(145,145,145), rgb(55,55,55)),
            MenuTheme::Light => (rgb(255,255,255), rgb(32,32,32), rgb(130,130,130), rgb(230,240,252)),
        };
        let selected = item.itemState & ODS_SELECTED != 0;
        let disabled = item.itemState & (ODS_DISABLED | ODS_GRAYED) != 0;
        let color = if selected { accent } else { bg };
        let brush = CreateSolidBrush(color);
        FillRect(item.hDC, &item.rcItem, brush);
        DeleteObject(brush);
        let mut text_rect = item.rcItem;
        text_rect.left += 36;
        if row.submenu { text_rect.right -= 20; }
        SetBkMode(item.hDC, TRANSPARENT as i32);
        SetTextColor(item.hDC, if disabled { muted } else { fg });
        let old = SelectObject(item.hDC, GetStockObject(DEFAULT_GUI_FONT as i32));
        DrawTextW(item.hDC, row.text.as_ptr(), -1, &mut text_rect, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
        if item.itemState & ODS_CHECKED != 0 {
            let mut mark = item.rcItem;
            mark.left += 9; mark.right = mark.left + 16;
            DrawTextW(item.hDC, [0x2713u16, 0].as_ptr(), -1, &mut mark, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
        }
        SelectObject(item.hDC, old);
        if row.submenu { draw_arrow(item, fg); }
        if item.itemState & ODS_FOCUS != 0 {
            windows_sys::Win32::Graphics::Gdi::DrawFocusRect(item.hDC, &item.rcItem);
        }
        true
    }
}

unsafe fn draw_arrow(item: &DRAWITEMSTRUCT, color: COLORREF) {
    // Tiny filled right-facing chevron; avoids relying on undocumented menu theming APIs.
    let x = item.rcItem.right - 14;
    let y = (item.rcItem.top + item.rcItem.bottom) / 2;
    let points = [
        windows_sys::Win32::Foundation::POINT { x: x - 3, y: y - 5 },
        windows_sys::Win32::Foundation::POINT { x: x + 2, y },
        windows_sys::Win32::Foundation::POINT { x: x - 3, y: y + 5 },
        windows_sys::Win32::Foundation::POINT { x: x - 1, y },
    ];
    let brush = CreateSolidBrush(color);
    let old = SelectObject(item.hDC, brush);
    let pen = windows_sys::Win32::Graphics::Gdi::CreatePen(0, 1, color);
    let old_pen = SelectObject(item.hDC, pen);
    windows_sys::Win32::Graphics::Gdi::Polygon(item.hDC, points.as_ptr(), points.len() as i32);
    SelectObject(item.hDC, old_pen);
    SelectObject(item.hDC, old);
    DeleteObject(pen); DeleteObject(brush);
}

const fn rgb(r: u8, g: u8, b: u8) -> COLORREF { r as u32 | ((g as u32) << 8) | ((b as u32) << 16) }

impl Drop for MenuThemeRenderer {
    fn drop(&mut self) {
        for brush in self.brushes.drain(..) { unsafe { DeleteObject(brush); } }
    }
}