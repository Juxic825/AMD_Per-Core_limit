use crate::{backend::Reading, settings};
use std::{collections::BTreeMap, io::{Read, Write}};

pub(crate) const FILE_NAME: &str = "CppcPreset.txt";
pub type Preset = BTreeMap<usize, Vec<u8>>;

pub fn load(cores: &[Reading]) -> Result<Preset, String> {
    // Legacy exe-relative presets can be imported explicitly by an administrator.
    // Startup always uses the verified Program Files copy.
    let (dir, _guard) = settings::open_data_dir(false)?;
    let path = dir.join(FILE_NAME);
    let mut content = String::new();
    settings::open_data_file(&path).and_then(|mut file| file.read_to_string(&mut content))
        .map_err(|err| format!("Cannot read {}: {err}", path.display()))?;
    let mut result = BTreeMap::new();
    for line in content.trim_start_matches('\u{feff}').lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') { continue; }
        let (key, value) = line.split_once('=').ok_or("Invalid preset line")?;
        let lower = key.trim().to_ascii_lowercase();
        let idx = lower.strip_prefix("core").and_then(|n| n.parse::<usize>().ok()).ok_or("Invalid core name")?;
        let core = cores.iter().find(|core| core.core == idx).ok_or("Unknown core in preset")?;
        let mut values: Vec<u8> = value.split(',').map(|v| v.trim().parse()).collect::<Result<_, _>>().map_err(|_| "Invalid preset Perf")?;
        if values.len() == 1 { values.resize(core.requests.len(), values[0]); }
        if values.len() != core.requests.len() || values.contains(&0) || result.insert(idx, values).is_some() {
            return Err("Invalid or duplicate core values".into());
        }
    }
    if result.len() != cores.len() || result.is_empty() { return Err("Preset must contain every core".into()); }
    Ok(result)
}

pub fn save(cores: &[Reading]) -> Result<(), String> {
    if cores.is_empty() || cores.iter().any(|row| row.requests.is_empty() || row.requests.contains(&0)) {
        return Err("Cannot save a preset without valid readings for every core.".into());
    }
    let (dir, _guard) = settings::open_data_dir(true)?;
    let path = dir.join(FILE_NAME);
    settings::write_data_file(&path, |file| {
        writeln!(file, "# CPPC MaxPerf preset v1")?;
        for row in cores {
            let same = row.requests.windows(2).all(|pair| pair[0] == pair[1]);
            let values = if same { &row.requests[..1] } else { &row.requests };
            writeln!(file, "Core{}={}", row.core, join(values))?;
        }
        Ok(())
    }).map_err(|err| format!("Cannot save {}: {err}", path.display()))
}

pub fn join(values: &[u8]) -> String {
    values.iter().map(u8::to_string).collect::<Vec<_>>().join(",")
}

pub fn command(preset: &Preset) -> String {
    let mut command = String::from("apply");
    for (core, values) in preset { command.push_str(&format!(" {core}={}", join(values))); }
    command
}
