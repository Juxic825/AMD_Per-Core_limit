//! Persistent UI preferences and opt-in logon startup settings for Windows.
//!
//! The startup task intentionally uses the inbox `schtasks.exe` command rather than
//! a shell or an elevation workaround.  Creating/updating the protected install
//! directory therefore succeeds only when the caller already has the required
//! Program Files permission (the normal installed-app path).

use std::env;
use std::ffi::c_void;
use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Seek, Write};
use std::os::windows::{
    ffi::{OsStrExt, OsStringExt},
    fs::{MetadataExt, OpenOptionsExt},
    io::{AsRawHandle, FromRawHandle},
    process::CommandExt,
};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::ptr::null_mut;
use std::time::{SystemTime, UNIX_EPOCH};
use windows_sys::Win32::Foundation::{GENERIC_READ, GENERIC_WRITE, INVALID_HANDLE_VALUE, LocalFree};
use windows_sys::Win32::Security::{
    Authorization::{ConvertStringSecurityDescriptorToSecurityDescriptorW, GetSecurityInfo, SDDL_REVISION_1, SE_FILE_OBJECT},
    GetAce, GetSecurityDescriptorControl, IsWellKnownSid, WinBuiltinAdministratorsSid,
    WinLocalSystemSid, ACCESS_ALLOWED_ACE, ACL, DACL_SECURITY_INFORMATION,
    ACCESS_ALLOWED_OBJECT_ACE, ACCESS_DENIED_OBJECT_ACE,
    OWNER_SECURITY_INFORMATION, SECURITY_ATTRIBUTES, SE_DACL_PROTECTED,
};
use windows_sys::Win32::Storage::FileSystem::{
    CreateDirectoryW, CreateFileW, GetFileInformationByHandle, MoveFileExW,
    BY_HANDLE_FILE_INFORMATION, CREATE_NEW, FILE_ATTRIBUTE_DIRECTORY, FILE_ATTRIBUTE_NORMAL,
    FILE_ATTRIBUTE_REPARSE_POINT, FILE_FLAG_BACKUP_SEMANTICS, FILE_FLAG_OPEN_REPARSE_POINT,
    FILE_GENERIC_EXECUTE, FILE_GENERIC_READ, FILE_READ_ATTRIBUTES, FILE_SHARE_READ,
    FILE_SHARE_WRITE, MOVEFILE_REPLACE_EXISTING, MOVEFILE_WRITE_THROUGH, READ_CONTROL,
};
use windows_sys::Win32::{
    System::SystemInformation::GetSystemDirectoryW,
    UI::Shell::{SHGetFolderPathW, CSIDL_PROGRAM_FILES},
};

const DATA_FOLDER: &str = "Juxic Per Core Limit";
const STARTUP_EXE: &str = "Juxic Per-Core Limit.exe";
pub(crate) const SERVICE_EXE: &str = "Juxic.Service.exe";
const TASK_PREFIX: &str = "Juxic Per Core Limit Native";
const STARTUP_ARGUMENT: &str = "--apply-preset-on-start";
const SILENT_ARGUMENT: &str = "--silent-startup";

#[cfg(windows)]
fn system_file(name: &str) -> PathBuf {
    let mut buffer = [0u16; 32768];
    let length = unsafe { GetSystemDirectoryW(buffer.as_mut_ptr(), buffer.len() as u32) } as usize;
    assert!(length > 0 && length < buffer.len(), "Windows system directory");
    PathBuf::from(String::from_utf16_lossy(&buffer[..length])).join(name)
}

fn local_app_data() -> Result<PathBuf, String> {
    env::var_os("LOCALAPPDATA").map(PathBuf::from)
        .ok_or_else(|| "LOCALAPPDATA is not available.".to_string())
}

fn sid() -> Result<String, String> {
    #[cfg(windows)]
    {
        let out = Command::new(system_file("whoami.exe")).creation_flags(0x08000000)
            .args(["/user", "/fo", "csv", "/nh"])
            .output().map_err(|e| format!("Could not determine current user SID: {e}"))?;
        if !out.status.success() { return Err("Could not determine current user SID.".into()); }
        let line = String::from_utf8_lossy(&out.stdout);
        let value = line.split(',').last().unwrap_or("").trim().trim_matches('"');
        if value.starts_with("S-") && value.len() > 2 { return Ok(value.to_string()); }
        Err("Could not determine current user SID.".into())
    }
    #[cfg(not(windows))] { Err("Windows settings are unavailable on this platform.".into()) }
}

fn language_path() -> Result<PathBuf, String> {
    Ok(local_app_data()?.join("Juxic Per Core Limit").join("language.txt"))
}

/// Returns true when the persisted UI language is English. Missing/invalid values
/// retain the existing application's default (Chinese), matching UserSettings.cs.
pub fn english() -> bool {
    language_path().ok().and_then(|p| fs::read_to_string(p).ok())
        .map(|s| matches!(s.trim().to_ascii_lowercase().as_str(), "en" | "en-us" | "english"))
        .unwrap_or(false)
}

pub fn set_english(value: bool) -> Result<(), String> {
    write_user_setting(&language_path()?, if value { "en" } else { "zh-CN" })
}

fn ui_preference(name: &str) -> Result<PathBuf, String> {
    Ok(local_app_data()?.join(DATA_FOLDER).join(name))
}

pub fn dark_theme() -> bool {
    ui_preference("theme.txt")
        .ok()
        .and_then(|path| fs::read_to_string(path).ok())
        .is_some_and(|value| value.trim() == "dark")
}

pub fn set_dark_theme(value: bool) -> Result<(), String> {
    write_user_setting(&ui_preference("theme.txt")?, if value { "dark" } else { "bright" })
}

pub fn close_to_tray() -> Option<bool> {
    let value = fs::read_to_string(ui_preference("close-to-tray.txt").ok()?).ok()?;
    match value.trim() {
        "hide" => Some(true),
        "exit" => Some(false),
        _ => None,
    }
}

pub fn set_close_to_tray(value: Option<bool>) -> Result<(), String> {
    write_user_setting(&ui_preference("close-to-tray.txt")?, match value {
        Some(true) => "hide",
        Some(false) => "exit",
        None => "ask",
    })
}

fn write_user_setting(path: &Path, value: &str) -> Result<(), String> {
    let parent = path.parent().ok_or("Invalid settings path.")?;
    fs::create_dir_all(parent).map_err(|err| err.to_string())?;
    let temp = temp_path(path);
    let mut file = OpenOptions::new().write(true).create_new(true).open(&temp)
        .map_err(|err| err.to_string())?;
    let result = (|| {
        file.write_all(value.as_bytes())?;
        drop(file);
        replace_file(&temp, path)
    })();
    if result.is_err() {
        let _ = fs::remove_file(&temp);
    }
    result.map_err(|err| err.to_string())
}

fn program_files() -> Result<PathBuf, String> {
    let mut buffer = [0u16; 260];
    let status = unsafe { SHGetFolderPathW(std::ptr::null_mut(), CSIDL_PROGRAM_FILES as i32, std::ptr::null_mut(), 0, buffer.as_mut_ptr()) };
    if status < 0 { return Err("Program Files is not available.".into()); }
    let end = buffer.iter().position(|&v| v == 0).filter(|&end| end > 0)
        .ok_or("Program Files is not available.")?;
    Ok(PathBuf::from(std::ffi::OsString::from_wide(&buffer[..end])))
}

/// Returns the machine-wide application folder without creating or validating it.
pub fn data_dir() -> Result<PathBuf, String> {
    Ok(program_files()?.join(DATA_FOLDER))
}

fn task_name(user_sid: &str) -> String { format!("{TASK_PREFIX} ({user_sid})") }

fn startup_task(name: &str) -> Result<Option<String>, String> {
    let output = scheduler(&["/Query", "/TN", name, "/XML"])?;
    Ok(output.status.success().then(|| scheduler_text(&output.stdout)))
}

fn task_silent(xml: &str) -> bool {
    xml.split_once("<Arguments>")
        .and_then(|(_, tail)| tail.split_once("</Arguments>"))
        .is_some_and(|(args, _)| args.split_whitespace().any(|arg| arg == SILENT_ARGUMENT))
}

pub fn startup_enabled() -> Result<bool, String> {
    Ok(startup_task(&task_name(&sid()?))?
        .is_some_and(|xml| !xml.contains("<Enabled>false</Enabled>")))
}

pub fn silent_startup() -> Result<bool, String> {
    Ok(startup_task(&task_name(&sid()?))?.is_some_and(|xml| task_silent(&xml)))
}

pub fn set_silent_startup(silent: bool) -> Result<(), String> {
    let user_sid = sid()?;
    let name = task_name(&user_sid);
    let xml = startup_task(&name)?.ok_or("Enable startup before changing silent startup.")?;
    if xml.contains("<Enabled>false</Enabled>") {
        return Err("Enable startup before changing silent startup.".into());
    }
    if task_silent(&xml) == silent {
        return Ok(());
    }
    install_startup_task(&user_sid, &name, silent)
}

pub fn set_startup(enabled: bool) -> Result<(), String> {
    let user_sid = sid()?;
    let name = task_name(&user_sid);
    if !enabled {
        let output = scheduler(&["/Delete", "/TN", &name, "/F"])?;
        if output.status.success() || output.stderr.windows(7).any(|w| w == b"ERROR: ") && String::from_utf8_lossy(&output.stderr).contains("not found") { return Ok(()); }
        return Err(scheduler_error(&output));
    }

    let silent = startup_task(&name)?.is_some_and(|xml| task_silent(&xml));
    install_startup_task(&user_sid, &name, silent)
}

fn install_startup_task(user_sid: &str, name: &str, silent: bool) -> Result<(), String> {
    let (dir, _guard) = open_data_dir(true)?;
    let source = env::current_exe().map_err(|err| format!("Cannot determine executable path: {err}"))?;
    let target = dir.join(STARTUP_EXE);
    let source_path = fs::canonicalize(&source).map_err(|err| err.to_string())?;
    if fs::canonicalize(&target).is_ok_and(|path| path == source_path) {
        // The same pathname could also be a reparse point. Validate it before using it.
        open_data_file(&target).map_err(|err| format!("Cannot open startup executable: {err}"))?;
    } else {
        let mut executable = File::open(&source).map_err(|err| err.to_string())?;
        write_data_file(&target, |file| io::copy(&mut executable, file).map(|_| ()))
            .map_err(|err| format!("Cannot install startup executable: {err}"))?;
    }
    {
        let mut installed = open_data_file(&target)
            .map_err(|err| format!("Cannot validate startup executable: {err}"))?;
        installed.seek(std::io::SeekFrom::Start(0)).map_err(|err| err.to_string())?;
        let mut signature = [0u8; 2];
        installed.read_exact(&mut signature).map_err(|err| format!("Cannot read startup executable: {err}"))?;
        if signature != [b'M', b'Z'] {
            return Err("The installed startup file is not a Windows executable.".into());
        }
    }

    let xml_path = dir.join(format!(".{}.xml.tmp", unique_suffix()));
    let mut xml = create_data_file(&xml_path).map_err(|err| err.to_string())?;
    let result = (|| {
        write_task_xml(&mut xml, user_sid, &target, &dir, silent)?;
        drop(xml);
        let xml_arg = xml_path.to_str().ok_or("Invalid task XML path.")?;
        let output = scheduler(&["/Create", "/TN", name, "/XML", xml_arg, "/F"])?;
        if output.status.success() { Ok(()) } else { Err(scheduler_error(&output)) }
    })();
    let _ = fs::remove_file(&xml_path);
    result
}

fn scheduler(args: &[&str]) -> Result<std::process::Output, String> {
    #[cfg(windows)] { Command::new(system_file("schtasks.exe")).creation_flags(0x08000000).args(args).output().map_err(|e| format!("Could not open Task Scheduler: {e}")) }
    #[cfg(not(windows))] { let _ = args; Err("Windows Task Scheduler is unavailable on this platform.".into()) }
}
fn scheduler_text(bytes: &[u8]) -> String {
    if bytes.len() >= 2 && bytes[0] == 0xff && bytes[1] == 0xfe {
        String::from_utf16_lossy(&bytes[2..].chunks_exact(2).map(|c| u16::from_le_bytes([c[0], c[1]])).collect::<Vec<_>>())
    } else { String::from_utf8_lossy(bytes).into_owned() }
}
fn scheduler_error(o: &std::process::Output) -> String {
    format!("Task Scheduler operation failed. {}", String::from_utf8_lossy(&o.stderr).trim())
}

struct LocalSecurityDescriptor(*mut c_void);

impl Drop for LocalSecurityDescriptor {
    fn drop(&mut self) {
        unsafe { LocalFree(self.0); }
    }
}

impl LocalSecurityDescriptor {
    fn new(directory: bool) -> io::Result<Self> {
        // SYSTEM and Administrators own and manage the data. Users may read and run it.
        let sddl = if directory {
            "O:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;GRGX;;;BU)"
        } else {
            "O:BAD:P(A;;FA;;;SY)(A;;FA;;;BA)(A;;GRGX;;;BU)"
        };
        let wide: Vec<_> = sddl.encode_utf16().chain(Some(0)).collect();
        let mut descriptor = null_mut();
        if unsafe {
            ConvertStringSecurityDescriptorToSecurityDescriptorW(
                wide.as_ptr(), SDDL_REVISION_1, &mut descriptor, null_mut(),
            )
        } == 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(Self(descriptor))
    }

    fn attributes(&self) -> SECURITY_ATTRIBUTES {
        SECURITY_ATTRIBUTES {
            nLength: std::mem::size_of::<SECURITY_ATTRIBUTES>() as u32,
            lpSecurityDescriptor: self.0,
            bInheritHandle: 0,
        }
    }
}

/// The directory handle excludes delete sharing. Keep it alive across path-based I/O.
pub(crate) fn open_data_dir(create: bool) -> Result<(PathBuf, File), String> {
    let dir = data_dir()?;
    let result = (|| -> io::Result<File> {
        // Refuse reparse points in the configured Program Files path as well.
        for parent in dir.ancestors().skip(1) {
            if fs::symlink_metadata(parent)?.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0 {
                return Err(io::Error::new(io::ErrorKind::InvalidData, "Program Files path contains a reparse point"));
            }
        }
        let open = || OpenOptions::new()
            .access_mode(READ_CONTROL | FILE_READ_ATTRIBUTES)
            .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
            .custom_flags(FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT)
            .open(&dir);
        let file = match open() {
            Err(err) if create && err.kind() == io::ErrorKind::NotFound => {
                let security = LocalSecurityDescriptor::new(true)?;
                if unsafe { CreateDirectoryW(path_wide(&dir).as_ptr(), &security.attributes()) } == 0 {
                    let err = io::Error::last_os_error();
                    if err.kind() != io::ErrorKind::AlreadyExists {
                        return Err(err);
                    }
                }
                open()?
            }
            result => result?,
        };
        validate_data_object(&file, true)?;
        Ok(file)
    })();
    result.map(|file| (dir.clone(), file))
        .map_err(|err| format!("Cannot use application data folder {}: {err}", dir.display()))
}

fn privileged_owner(sid: *mut c_void) -> bool {
    !sid.is_null() && unsafe {
        IsWellKnownSid(sid, WinLocalSystemSid) != 0 || IsWellKnownSid(sid, WinBuiltinAdministratorsSid) != 0
    }
}

fn validate_data_object(file: &File, directory: bool) -> io::Result<()> {
    let unsafe_object = || io::Error::new(io::ErrorKind::InvalidData, "Expected a non-reparse object owned and writable only by Administrators or SYSTEM");
    let mut info = std::mem::MaybeUninit::<BY_HANDLE_FILE_INFORMATION>::uninit();
    if unsafe { GetFileInformationByHandle(file.as_raw_handle(), info.as_mut_ptr()) } == 0 {
        return Err(io::Error::last_os_error());
    }
    let attrs = unsafe { info.assume_init() }.dwFileAttributes;
    if attrs & FILE_ATTRIBUTE_REPARSE_POINT != 0 || (attrs & FILE_ATTRIBUTE_DIRECTORY != 0) != directory {
        return Err(unsafe_object());
    }

    let mut owner = null_mut();
    let mut dacl: *mut ACL = null_mut();
    let mut security = LocalSecurityDescriptor(null_mut());
    let status = unsafe {
        GetSecurityInfo(file.as_raw_handle(), SE_FILE_OBJECT, OWNER_SECURITY_INFORMATION | DACL_SECURITY_INFORMATION,
            &mut owner, null_mut(), &mut dacl, null_mut(), &mut security.0)
    };
    if status != 0 {
        return Err(io::Error::from_raw_os_error(status as i32));
    }
    let mut control = 0;
    let mut revision = 0;
    if unsafe { GetSecurityDescriptorControl(security.0, &mut control, &mut revision) } == 0 {
        return Err(io::Error::last_os_error());
    }
    if !privileged_owner(owner) || dacl.is_null() || control & SE_DACL_PROTECTED == 0 {
        return Err(unsafe_object());
    }

    // Accept ordinary deny ACEs and read/execute-only grants for other principals.
    // Reject unfamiliar ACE types because they can carry additional access grants.
    for index in 0..unsafe { (*dacl).AceCount } as u32 {
        let mut ace = null_mut();
        if unsafe { GetAce(dacl, index, &mut ace) } == 0 {
            return Err(io::Error::last_os_error());
        }
        // Standard ACCESS_ALLOWED_ACE_TYPE and ACCESS_DENIED_ACE_TYPE.
        match unsafe { (*ace.cast::<windows_sys::Win32::Security::ACE_HEADER>()).AceType } {
            0 | 1 => {
                let sid = unsafe { ace.cast::<u8>().add(8).cast() };
                let mask = unsafe { (*ace.cast::<ACCESS_ALLOWED_ACE>()).Mask };
                if !privileged_owner(sid) && unsafe { (*ace.cast::<ACCESS_ALLOWED_ACE>()).Header.AceType == 0 }
                    && mask & !(FILE_GENERIC_READ | FILE_GENERIC_EXECUTE) != 0 {
                    return Err(unsafe_object());
                }
            }
            5 => {
                let ace = ace.cast::<ACCESS_ALLOWED_OBJECT_ACE>();
                let flags = unsafe { (*ace).Flags };
                let sid_offset = 12usize
                    + if flags & 1 != 0 { 16 } else { 0 }
                    + if flags & 2 != 0 { 16 } else { 0 };
                let sid = unsafe { (ace.cast::<u8>()).add(sid_offset).cast() };
                if !privileged_owner(sid) && unsafe { (*ace).Mask } & !(FILE_GENERIC_READ | FILE_GENERIC_EXECUTE) != 0 {
                    return Err(unsafe_object());
                }
            }
            6 => {
                let ace = ace.cast::<ACCESS_DENIED_OBJECT_ACE>();
                let flags = unsafe { (*ace).Flags };
                let sid_offset = 12usize
                    + if flags & 1 != 0 { 16 } else { 0 }
                    + if flags & 2 != 0 { 16 } else { 0 };
                let sid = unsafe { (ace.cast::<u8>()).add(sid_offset).cast() };
                if !privileged_owner(sid) && unsafe { (*ace).Mask } & !(FILE_GENERIC_READ | FILE_GENERIC_EXECUTE) != 0 {
                    return Err(unsafe_object());
                }
            }
            2..=4 | 7..=255 => return Err(unsafe_object()),
        }
    }
    Ok(())
}

pub(crate) fn open_data_file(path: &Path) -> io::Result<File> {
    let file = OpenOptions::new().access_mode(GENERIC_READ | READ_CONTROL)
        .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE)
        .custom_flags(FILE_FLAG_OPEN_REPARSE_POINT).open(path)?;
    validate_data_object(&file, false)?;
    Ok(file)
}

fn create_data_file(path: &Path) -> io::Result<File> {
    let security = LocalSecurityDescriptor::new(false)?;
    let handle = unsafe {
        CreateFileW(path_wide(path).as_ptr(), GENERIC_WRITE, 0, &security.attributes(),
            CREATE_NEW, FILE_ATTRIBUTE_NORMAL, null_mut())
    };
    if handle == INVALID_HANDLE_VALUE {
        return Err(io::Error::last_os_error());
    }
    Ok(unsafe { File::from_raw_handle(handle) })
}

/// Write within a checked data directory held open by the caller, then publish by rename.
pub(crate) fn write_data_file(path: &Path, write: impl FnOnce(&mut File) -> io::Result<()>) -> io::Result<()> {
    let temp = temp_path(path);
    let mut file = create_data_file(&temp)?;
    let result = (|| {
        write(&mut file)?;
        file.sync_all()?;
        drop(file);
        replace_file(&temp, path)
    })();
    if result.is_err() {
        let _ = fs::remove_file(&temp);
    }
    result
}

fn path_wide(path: &Path) -> Vec<u16> {
    path.as_os_str().encode_wide().chain(Some(0)).collect()
}

fn replace_file(temp: &Path, target: &Path) -> io::Result<()> {
    if unsafe { MoveFileExW(path_wide(temp).as_ptr(), path_wide(target).as_ptr(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) } == 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(())
}

fn temp_path(path: &Path) -> PathBuf {
    path.with_extension(format!("{}.tmp", unique_suffix()))
}

fn unique_suffix() -> String {
    use std::sync::atomic::{AtomicU64, Ordering};
    static NEXT: AtomicU64 = AtomicU64::new(0);
    let timestamp = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos();
    format!("{}.{}.{}", std::process::id(), timestamp, NEXT.fetch_add(1, Ordering::Relaxed))
}

fn write_task_xml(f: &mut File, sid: &str, exe: &Path, dir: &Path, silent: bool) -> Result<(), String> {
    fn esc(s: &str) -> String { s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;") }
    let e = esc(&exe.to_string_lossy()); let d = esc(&dir.to_string_lossy()); let s = esc(sid);
    let args = if silent { format!("{STARTUP_ARGUMENT} {SILENT_ARGUMENT}") } else { STARTUP_ARGUMENT.to_string() };
    let xml = format!(r#"<?xml version="1.0" encoding="UTF-16"?>
<Task xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task" version="1.2"><Triggers><LogonTrigger><Enabled>true</Enabled><UserId>{s}</UserId></LogonTrigger></Triggers><Principals><Principal id="Author"><UserId>{s}</UserId><LogonType>InteractiveToken</LogonType><RunLevel>HighestAvailable</RunLevel></Principal></Principals><Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries><StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><ExecutionTimeLimit>PT0S</ExecutionTimeLimit><Enabled>true</Enabled></Settings><Actions Context="Author"><Exec><Command>{e}</Command><Arguments>{args}</Arguments><WorkingDirectory>{d}</WorkingDirectory></Exec></Actions></Task>"#);
    f.write_all(&[0xFF, 0xFE]).map_err(|e| e.to_string())?;
    for unit in xml.encode_utf16() { f.write_all(&unit.to_le_bytes()).map_err(|e| e.to_string())?; }
    f.flush().map_err(|e| e.to_string())
}
