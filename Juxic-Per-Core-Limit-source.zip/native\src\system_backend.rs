use std::{ffi::{OsStr, OsString}, fs::{self, File}, io::{self, Read, Write}, os::windows::{ffi::{OsStrExt, OsStringExt}, io::{AsRawHandle, FromRawHandle}}, ptr::null_mut, time::{Duration, Instant}};
use windows_sys::Win32::{Foundation::*, Security::{GetTokenInformation, IsWellKnownSid, TokenUser, WinLocalSystemSid, TOKEN_QUERY, TOKEN_USER}, Storage::FileSystem::*, System::{Pipes::*, Services::*, Threading::{OpenProcess, OpenProcessToken, PROCESS_QUERY_LIMITED_INFORMATION}}};

const SERVICE_NAME: &str = "Juxic.Service";
const PIPE_NAME: &str = r"\\.\pipe\Juxic.Service.v1";
const HELLO: &[u8] = b"JUXIC/1\n";
const ACCEPTED: &[u8] = b"JUXIC/1 OK\n";
const DELETE_PENDING: &str = "Juxic.Service.exe.delete-pending";

fn wide(text: &OsStr) -> Vec<u16> { text.encode_wide().chain(Some(0)).collect() }
fn fail() -> String { io::Error::last_os_error().to_string() }
fn service_handle(raw: SC_HANDLE) -> Result<ServiceHandle, String> {
    if raw.is_null() { Err(fail()) } else { Ok(ServiceHandle(raw)) }
}
struct ServiceHandle(SC_HANDLE);
impl Drop for ServiceHandle { fn drop(&mut self) { unsafe { CloseServiceHandle(self.0); } } }
struct ScmHandle(SC_HANDLE);
impl Drop for ScmHandle { fn drop(&mut self) { unsafe { CloseServiceHandle(self.0); } } }

fn system_token(process: HANDLE) -> bool {
    unsafe {
        let mut token = null_mut();
        if OpenProcessToken(process, TOKEN_QUERY, &mut token) == 0 { return false; }
        let mut length = 0;
        GetTokenInformation(token, TokenUser, null_mut(), 0, &mut length);
        let mut data = vec![0usize; (length as usize).div_ceil(std::mem::size_of::<usize>())];
        let ok = length as usize >= std::mem::size_of::<TOKEN_USER>() && GetTokenInformation(token, TokenUser, data.as_mut_ptr().cast(), length, &mut length) != 0
            && IsWellKnownSid((*data.as_ptr().cast::<TOKEN_USER>()).User.Sid, WinLocalSystemSid) != 0;
        CloseHandle(token);
        ok
    }
}

fn data_dir() -> Result<(std::path::PathBuf, File), String> { crate::settings::open_data_dir(true) }
fn scm() -> Result<ScmHandle, String> {
    let raw = unsafe { OpenSCManagerW(null_mut(), null_mut(), SC_MANAGER_CONNECT | SC_MANAGER_CREATE_SERVICE) };
    if raw.is_null() { Err(fail()) } else { Ok(ScmHandle(raw)) }
}
fn query_state(service: SC_HANDLE) -> Result<u32, String> {
    unsafe {
        let mut status: SERVICE_STATUS_PROCESS = std::mem::zeroed();
        let mut needed = 0;
        if QueryServiceStatusEx(service, SC_STATUS_PROCESS_INFO, (&mut status as *mut SERVICE_STATUS_PROCESS).cast(), std::mem::size_of_val(&status) as u32, &mut needed) == 0 { return Err(fail()); }
        Ok(status.dwCurrentState)
    }
}
fn wait_state(service: SC_HANDLE, wanted: u32, timeout: Duration) -> Result<(), String> {
    let deadline = Instant::now() + timeout;
    loop {
        let state = query_state(service)?;
        if state == wanted { return Ok(()); }
        if state == SERVICE_STOPPED && wanted != SERVICE_STOPPED { return Err("Juxic Service stopped during startup".into()); }
        if Instant::now() >= deadline { return Err("Timed out waiting for Juxic Service state".into()); }
        std::thread::sleep(Duration::from_millis(50));
    }
}
fn open_service(manager: SC_HANDLE) -> Result<ServiceHandle, String> {
    service_handle(unsafe { OpenServiceW(manager, wide(OsStr::new(SERVICE_NAME)).as_ptr(), SERVICE_QUERY_STATUS | SERVICE_QUERY_CONFIG | SERVICE_START | SERVICE_STOP | DELETE) })
}

fn install_service() -> Result<(), String> {
    let (dir, _guard) = data_dir()?;
    let exe = dir.join(crate::settings::SERVICE_EXE);
    let embedded = include_bytes!(concat!(env!("OUT_DIR"), "/Juxic.Service.exe"));
    let mut existing = Vec::new();
    match crate::settings::open_data_file(&exe) {
        Ok(file) => { file.take(embedded.len() as u64 + 1).read_to_end(&mut existing).map_err(|error| error.to_string())?; }
        Err(error) if error.kind() == io::ErrorKind::NotFound => {}
        Err(error) => return Err(format!("Cannot validate Juxic Service image: {error}")),
    }
    if existing.as_slice() != embedded {
        crate::settings::write_data_file(&exe, |file| file.write_all(embedded))
            .map_err(|error| format!("Cannot update Juxic Service. Close any other Juxic session first: {error}"))?;
    }
    let manager = scm()?;
    let service = unsafe { CreateServiceW(manager.0, wide(OsStr::new(SERVICE_NAME)).as_ptr(), wide(OsStr::new("Juxic System Service")).as_ptr(), SERVICE_QUERY_STATUS | SERVICE_QUERY_CONFIG | SERVICE_START | SERVICE_STOP | DELETE, SERVICE_WIN32_OWN_PROCESS, SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL, wide(OsStr::new(&format!("\"{}\"", exe.display()))).as_ptr(), null_mut(), null_mut(), null_mut(), wide(OsStr::new("LocalSystem")).as_ptr(), null_mut()) };
    if !service.is_null() { drop(ServiceHandle(service)); return Ok(()); }
    if unsafe { GetLastError() } != ERROR_SERVICE_EXISTS { return Err(fail()); }
    let service = open_service(manager.0)?;
    let mut needed = 0;
    unsafe { QueryServiceConfigW(service.0, null_mut(), 0, &mut needed); }
    if needed == 0 { return Err(fail()); }
    let mut buffer = vec![0u64; (needed as usize).div_ceil(8)];
    let config = buffer.as_mut_ptr().cast::<QUERY_SERVICE_CONFIGW>();
    if unsafe { QueryServiceConfigW(service.0, config, needed, &mut needed) } == 0 { return Err(fail()); }
    let config = unsafe { &*config };
    let raw_path = unsafe { std::ffi::OsString::from_wide(std::slice::from_raw_parts(config.lpBinaryPathName, (0..).take_while(|&i| *config.lpBinaryPathName.add(i) != 0).count())) };
    let actual = raw_path.to_string_lossy();
    let expected = format!("\"{}\"", exe.display());
    if !actual.eq_ignore_ascii_case(&expected) || config.dwServiceType != SERVICE_WIN32_OWN_PROCESS || config.dwStartType != SERVICE_DEMAND_START || config.lpServiceStartName.is_null() {
        return Err("Existing Juxic Service configuration is not trusted".into());
    }
    let account: String = unsafe { OsString::from_wide(std::slice::from_raw_parts(config.lpServiceStartName, (0..).take_while(|&i| *config.lpServiceStartName.add(i) != 0).count())) }.to_string_lossy().into_owned();
    if !account.eq_ignore_ascii_case("LocalSystem") { return Err("Existing Juxic Service is not LocalSystem".into()); }
    Ok(())
}

fn start_service() -> Result<(), String> {
    let manager = scm()?;
    let service = open_service(manager.0)?;
    match query_state(service.0)? {
        SERVICE_RUNNING => Ok(()),
        SERVICE_START_PENDING => wait_state(service.0, SERVICE_RUNNING, Duration::from_secs(20)),
        SERVICE_STOPPED => {
            if unsafe { StartServiceW(service.0, 0, null_mut()) } == 0 && unsafe { GetLastError() } != ERROR_SERVICE_ALREADY_RUNNING { return Err(fail()); }
            wait_state(service.0, SERVICE_RUNNING, Duration::from_secs(20))
        }
        _ => Err("Juxic Service is changing state".into()),
    }
}

pub fn await_service_stop() -> Result<(), String> {
    let manager = scm()?;
    let service = open_service(manager.0)?;
    wait_state(service.0, SERVICE_STOPPED, Duration::from_secs(5))
}
pub fn uninstall() -> Result<(), String> {
    let manager = scm()?;
    let service = open_service(manager.0)?;
    if query_state(service.0)? != SERVICE_STOPPED {
        let mut status = unsafe { std::mem::zeroed::<SERVICE_STATUS>() };
        if unsafe { ControlService(service.0, SERVICE_CONTROL_STOP, &mut status) } == 0 && unsafe { GetLastError() } != ERROR_SERVICE_NOT_ACTIVE { return Err(fail()); }
        wait_state(service.0, SERVICE_STOPPED, Duration::from_secs(30))?;
    }
    if unsafe { DeleteService(service.0) } == 0 { return Err(fail()); }
    drop(service);
    for _ in 0..100 {
        match open_service(manager.0) {
            Ok(service) => { drop(service); std::thread::sleep(Duration::from_millis(50)); }
            Err(_) if unsafe { GetLastError() } == ERROR_SERVICE_DOES_NOT_EXIST => break,
            Err(err) => return Err(err),
        }
    }
    let (dir, _guard) = data_dir()?;
    let exe = dir.join(crate::settings::SERVICE_EXE);
    match fs::remove_file(&exe) {
        Ok(()) => {},
        Err(error) if error.kind() == io::ErrorKind::PermissionDenied => {
            crate::settings::write_data_file(&dir.join(DELETE_PENDING), |_| Ok(())).map_err(|e| e.to_string())?;
        },
        Err(error) => return Err(error.to_string()),
    }
    if exe.exists() { return Err("Juxic Service binary cleanup verification failed".into()); }
    Ok(())
}

fn authenticate(pipe: HANDLE, expected_pid: u32) -> Result<(), String> {
    unsafe {
        let mut pid = 0;
        if GetNamedPipeServerProcessId(pipe, &mut pid) == 0 { return Err(fail()); }
        if pid != expected_pid { return Err("Juxic Service pipe is not owned by the registered service process".into()); }
        let client = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
        if client.is_null() { return Err(fail()); }
        let valid = system_token(client);
        CloseHandle(client);
        if !valid { return Err("Juxic Service pipe client is not LocalSystem".into()); }
    }
    Ok(())
}

fn service_pid() -> Result<u32, String> {
    let manager = scm()?;
    let service = open_service(manager.0)?;
    let mut status: SERVICE_STATUS_PROCESS = unsafe { std::mem::zeroed() };
    let mut needed = 0;
    if unsafe { QueryServiceStatusEx(service.0, SC_STATUS_PROCESS_INFO, (&mut status as *mut SERVICE_STATUS_PROCESS).cast(), std::mem::size_of_val(&status) as u32, &mut needed) } == 0 { return Err(fail()); }
    if status.dwCurrentState != SERVICE_RUNNING || status.dwProcessId == 0 { return Err("Juxic Service is not running".into()); }
    Ok(status.dwProcessId)
}

fn connect_pipe(expected_pid: u32) -> Result<File, String> {
    let deadline = Instant::now() + Duration::from_secs(20);
    loop {
        let handle = unsafe { CreateFileW(wide(OsStr::new(PIPE_NAME)).as_ptr(), GENERIC_READ | GENERIC_WRITE, 0, null_mut(), OPEN_EXISTING, 0, null_mut()) };
        if handle != INVALID_HANDLE_VALUE {
            let file = unsafe { File::from_raw_handle(handle) };
            authenticate(file.as_raw_handle(), expected_pid)?;
            let mut writer = file.try_clone().map_err(|e| e.to_string())?;
            writer.write_all(HELLO).map_err(|e| e.to_string())?;
            let mut response = vec![0; ACCEPTED.len()];
            (&file).read_exact(&mut response).map_err(|e| e.to_string())?;
            if response != ACCEPTED { return Err("Juxic Service rejected IPC handshake".into()); }
            return Ok(file);
        }
        let error = unsafe { GetLastError() };
        if error != ERROR_PIPE_BUSY && error != ERROR_FILE_NOT_FOUND { return Err(fail()); }
        if Instant::now() >= deadline { return Err("Juxic Service IPC connection timed out".into()); }
        if error == ERROR_FILE_NOT_FOUND { std::thread::sleep(Duration::from_millis(50)); }
        else { unsafe { WaitNamedPipeW(wide(OsStr::new(PIPE_NAME)).as_ptr(), 100); } }
    }
}

pub fn launch() -> Result<(File, File), String> {
    install_service()?;
    start_service()?;
    let pipe = connect_pipe(service_pid()?)?;
    Ok((pipe.try_clone().map_err(|e| e.to_string())?, pipe))
}
