//! Native notification-area icon and close/menu interactions.

use std::mem::size_of;
use std::ptr::{null, null_mut};
use windows_sys::Win32::Foundation::{HWND, LPARAM, POINT};
use windows_sys::Win32::UI::Controls::{
    TaskDialogIndirect, TASKDIALOGCONFIG, TASKDIALOG_BUTTON, TDF_ALLOW_DIALOG_CANCELLATION,
    TDF_POSITION_RELATIVE_TO_WINDOW,
};
use windows_sys::Win32::UI::Shell::{
    Shell_NotifyIconW, NIF_ICON, NIF_MESSAGE, NIF_SHOWTIP, NIF_TIP, NIM_ADD, NIM_DELETE,
    NIM_SETVERSION, NIN_SELECT, NOTIFYICONDATAW, NOTIFYICON_VERSION_4,
};
use windows_sys::Win32::UI::WindowsAndMessaging::{
    ChangeWindowMessageFilterEx, CreatePopupMenu, DestroyMenu, GetCursorPos, LoadImageW,
    GetSystemMetrics, IMAGE_ICON, LR_SHARED, SM_CXSMICON, SM_CYSMICON, HICON,
    PostMessageW, RegisterWindowMessageW, SetForegroundWindow, TrackPopupMenu,
    MSGFLT_ALLOW, TPM_BOTTOMALIGN, TPM_LEFTALIGN, TPM_RIGHTBUTTON,
    TPM_RETURNCMD, TPM_NONOTIFY, WM_APP, WM_CONTEXTMENU, WM_LBUTTONUP, WM_RBUTTONUP,
};

pub const CALLBACK_MESSAGE: u32 = WM_APP + 42;
const ICON_ID: u32 = 1;
const MENU_OPEN: u32 = 1;
const MENU_RESTORE: u32 = 2;
const MENU_EXIT: u32 = 3;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TrayEvent { Open, Menu }
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TrayCommand { Open, Exit, Restore }

pub struct TrayIcon {
    hwnd: HWND,
    added: bool,
    wanted: bool,
    icon: HICON,
    taskbar_created_message: u32,
}

impl TrayIcon {
    pub fn new(hwnd: HWND, instance: windows_sys::Win32::Foundation::HINSTANCE) -> Self {
        let taskbar_created_message = unsafe { RegisterWindowMessageW(wide("TaskbarCreated").as_ptr()) };
        if taskbar_created_message != 0 {
            unsafe { ChangeWindowMessageFilterEx(hwnd, taskbar_created_message, MSGFLT_ALLOW, null_mut()); }
        }
        unsafe { ChangeWindowMessageFilterEx(hwnd, CALLBACK_MESSAGE, MSGFLT_ALLOW, null_mut()); }
        let icon = unsafe {
            LoadImageW(instance, crate::APP_ICON, IMAGE_ICON,
                GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), LR_SHARED) as HICON
        };
        Self { hwnd, added: false, wanted: false, icon, taskbar_created_message }
    }

    pub fn action(&self, lparam: LPARAM) -> Option<TrayEvent> {
        action(lparam)
    }

    fn data(&self) -> NOTIFYICONDATAW {
        let mut data: NOTIFYICONDATAW = unsafe { std::mem::zeroed() };
        data.cbSize = size_of::<NOTIFYICONDATAW>() as u32;
        data.hWnd = self.hwnd;
        data.uID = ICON_ID;
        data.uCallbackMessage = CALLBACK_MESSAGE;
        data.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP | NIF_SHOWTIP;
        data.hIcon = self.icon;
        let tip: Vec<u16> = crate::TITLE.encode_utf16().chain(Some(0)).collect();
        let len = tip.len().min(data.szTip.len());
        data.szTip[..len].copy_from_slice(&tip[..len]);
        data
    }

    pub fn add(&mut self) -> bool {
        self.wanted = true;
        if self.added { return true; }
        let mut data = self.data();
        let ok = unsafe { Shell_NotifyIconW(NIM_ADD, &mut data) } != 0;
        if ok {
            data.Anonymous.uVersion = NOTIFYICON_VERSION_4;
            unsafe { Shell_NotifyIconW(NIM_SETVERSION, &mut data); }
        }
        self.added = ok;
        ok
    }

    pub fn remove(&mut self) {
        self.wanted = false;
        if self.added {
            let mut data = self.data();
            unsafe { Shell_NotifyIconW(NIM_DELETE, &mut data); }
            self.added = false;
        }
    }

    pub fn taskbar_created(&mut self, message: u32) -> bool {
        if message == 0 || message != self.taskbar_created_message || !self.wanted { return false; }
        self.added = false;
        true
    }
}

impl Drop for TrayIcon {
    fn drop(&mut self) { self.remove(); }
}

pub fn action(lparam: LPARAM) -> Option<TrayEvent> {
    match (lparam as u32) & 0xffff {
        value if value == WM_LBUTTONUP || value == NIN_SELECT || value == (NIN_SELECT + 1) => Some(TrayEvent::Open),
        WM_RBUTTONUP | WM_CONTEXTMENU => Some(TrayEvent::Menu),
        _ => None,
    }
}

pub fn show_menu(hwnd: HWND, english: bool, dark: bool) -> Option<TrayCommand> {
    let menu = unsafe { CreatePopupMenu() };
    if menu.is_null() { return None; }
    let open = if english { "Open" } else { "打开" };
    let restore = if english { "Stop frequency limiting" } else { "停止限制频率" };
    let exit = if english { "Exit completely" } else { "完全退出" };
    use crate::menu_theme::{MenuTheme, MenuThemeRenderer};
    let mut renderer = MenuThemeRenderer::new(MenuTheme::from_dark(dark));
    let ok = unsafe {
        renderer.apply_background(menu);
        renderer.append(menu, MENU_OPEN as usize, open, 0)
            && renderer.append(menu, MENU_RESTORE as usize, restore, 0)
            && renderer.append(menu, MENU_EXIT as usize, exit, 0)
    };
    if !ok { unsafe { DestroyMenu(menu); } return None; }
    let mut point: POINT = unsafe { std::mem::zeroed() };
    if unsafe { GetCursorPos(&mut point) } == 0 { unsafe { DestroyMenu(menu); } return None; }
    unsafe {
        SetForegroundWindow(hwnd);
        let selected = crate::menu_theme::with_renderer(&renderer, ||
            TrackPopupMenu(menu, TPM_LEFTALIGN | TPM_BOTTOMALIGN | TPM_RIGHTBUTTON | TPM_RETURNCMD | TPM_NONOTIFY,
                point.x, point.y, 0, hwnd, null()));
        PostMessageW(hwnd, 0x0000, 0, 0);
        DestroyMenu(menu);
        match selected as u32 {
            MENU_OPEN => Some(TrayCommand::Open),
            MENU_RESTORE => Some(TrayCommand::Restore),
            MENU_EXIT => Some(TrayCommand::Exit),
            _ => None,
        }
    }
}

pub fn prompt_close(hwnd: HWND, english: bool) -> Option<(bool, bool)> {
    const HIDE: i32 = 100;
    const EXIT: i32 = 101;
    let title = wide(crate::TITLE);
    let instruction = wide(if english { "Close the application?" } else { "关闭应用程序？" });
    let hide = wide(if english { "Hide to tray" } else { "隐藏到托盘" });
    let exit = wide(if english { "Close completely" } else { "完全关闭" });
    let cancel = wide(if english { "Cancel" } else { "取消" });
    let verification = wide(if english { "Remember my choice" } else { "记住我的选择" });
    let buttons = [
        TASKDIALOG_BUTTON { nButtonID: HIDE, pszButtonText: hide.as_ptr() },
        TASKDIALOG_BUTTON { nButtonID: EXIT, pszButtonText: exit.as_ptr() },
        TASKDIALOG_BUTTON { nButtonID: 2, pszButtonText: cancel.as_ptr() },
    ];
    let mut config: TASKDIALOGCONFIG = unsafe { std::mem::zeroed() };
    config.cbSize = size_of::<TASKDIALOGCONFIG>() as u32;
    config.hwndParent = hwnd;
    config.dwFlags = TDF_ALLOW_DIALOG_CANCELLATION | TDF_POSITION_RELATIVE_TO_WINDOW;
    config.cButtons = buttons.len() as u32;
    config.pButtons = buttons.as_ptr();
    config.nDefaultButton = HIDE;
    config.hInstance = unsafe { windows_sys::Win32::System::LibraryLoader::GetModuleHandleW(null()) };
    config.Anonymous1.pszMainIcon = crate::APP_ICON;
    config.pszWindowTitle = title.as_ptr();
    config.pszMainInstruction = instruction.as_ptr();
    config.pszVerificationText = verification.as_ptr();
    let mut button = 0i32;
    let mut radio = 0i32;
    let mut checked = 0i32;
    let status = unsafe { TaskDialogIndirect(&config, &mut button, &mut radio, &mut checked) };
    if status < 0 { return None; }
    match button {
        HIDE => Some((true, checked != 0)),
        EXIT => Some((false, checked != 0)),
        _ => None,
    }
}

fn wide(value: &str) -> Vec<u16> { value.encode_utf16().chain(Some(0)).collect() }
